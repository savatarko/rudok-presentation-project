package controller.listeners;

import observer.Publisher;
import observer.Subscriber;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

public class SlideMouseListener implements MouseListener, Publisher, MouseMotionListener {

    private Subscriber subscriber;
    @Override
    public void mouseClicked(MouseEvent e) {
        notifySubscribers(e);
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {


    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void notifySubscribers(Object notification) {
        subscriber.update(notification);
    }

    @Override
    public void removeSubscriber(Subscriber sub) {
        subscriber = sub;
    }

    @Override
    public void addSubscriber(Subscriber sub) {
        subscriber= sub;
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        notifySubscribers(e);
    }

    @Override
    public void mouseMoved(MouseEvent e) {

    }
}
