package controller.listeners;

import model.Project;
import model.jtree.MyPopUpMenu;
import model.jtree.MyTreeNode;
import view.MainFrame;

import javax.swing.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class MyMouseListener implements MouseListener {

    @Override
    public void mouseClicked(MouseEvent e) {
        if(e.getClickCount() == 2 && MainFrame.getInstance().getMyTree().getLastSelectedPathComponent() !=null)
        {
            if(((MyTreeNode)MainFrame.getInstance().getMyTree().getLastSelectedPathComponent()).getNode() instanceof Project)
            {
                MainFrame.getInstance().getProjectView().setProject((Project)(((MyTreeNode)MainFrame.getInstance().getMyTree().getLastSelectedPathComponent()).getNode()));
            }
        }
        else if(SwingUtilities.isRightMouseButton(e))
        {
            MyPopUpMenu myPopUpMenu = new MyPopUpMenu();
            myPopUpMenu.show(e.getComponent(), e.getX(),e.getY());
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
