package controller.actions;

import model.Presentation;
import model.jtree.MyTreeNode;
import view.ChangePresentationBgDialog;
import view.MainFrame;

import java.awt.event.ActionEvent;

public class ChangePresentationBgAction extends AbstractRudokAction{
    public ChangePresentationBgAction() {
        putValue(NAME, "Change background");
        putValue(SHORT_DESCRIPTION, "Change backgroung");
        putValue(SMALL_ICON, loadIcon("ActionPics/bg.png"));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(MainFrame.getInstance().getMyTree().getSelectionModel().getSelectionPath() == null)
            return;
        MyTreeNode selected = (MyTreeNode) MainFrame.getInstance().getMyTree().getSelectionModel().getSelectionPath().getLastPathComponent();
        if(selected!=null && selected.getNode() instanceof Presentation)
        {
            ChangePresentationBgDialog changePresentationAuthorDialog = new ChangePresentationBgDialog((Presentation)selected.getNode());
        }
    }
}
