package controller.actions;

import model.Presentation;
import model.Project;
import model.RuNodeComposite;
import model.jtree.MyTreeNode;
import view.MainFrame;

import javax.swing.*;
import javax.swing.tree.MutableTreeNode;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

public class SharePasteAction extends AbstractRudokAction{

    public SharePasteAction() {
        //putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(ActionEvent.CTRL_MASK, KeyEvent.VK_N));
        putValue(NAME, "Share to");
        putValue(SHORT_DESCRIPTION, "Share to");
        //putValue(SMALL_ICON, loadIcon("ActionPics/NewProjectAction.png"));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(((MyTreeNode) MainFrame.getInstance().getMyTree().getSelectionModel().getSelectionPath().getLastPathComponent()).getNode() instanceof Project)
        {
            MyTreeNode myTreeNode = new MyTreeNode();
            try {
                //myTreeNode =(MyTreeNode) MainFrame.getInstance().getClipboardnode();
                Presentation presentation = new Presentation((Presentation)MainFrame.getInstance().getClipboardnode().getNode());
                presentation.copyPresentation((Presentation)MainFrame.getInstance().getClipboardnode().getNode());
                //myTreeNode = MainFrame.getInstance().getClipboardnode();
                myTreeNode = new MyTreeNode(presentation, "share");
                MyTreeNode node = (((MyTreeNode) MainFrame.getInstance().getMyTree().getSelectionModel().getSelectionPath().getLastPathComponent()));
                node.add(myTreeNode);
                //presentation.addshare(myTreeNode);//UZIMAM ONU KOJA JE KOPIRANA
                ((Presentation)MainFrame.getInstance().getClipboardnode().getNode()).addshare(myTreeNode);
                presentation.setShared(((Presentation)MainFrame.getInstance().getClipboardnode().getNode()).getShared());
                ((RuNodeComposite)node.getNode()).addChild(presentation);

                //myTreeNode.getNode().setName(myTreeNode.getNode().getName().concat(" copy"));
                //((RuNodeComposite)((MyTreeNode) MainFrame.getInstance().getMyTree().getSelectionModel().getSelectionPath().getLastPathComponent()).getNode().getParent()).addChild(myTreeNode);
            }
            catch (Exception ee)
            {
                ee.printStackTrace();
            }
            SwingUtilities.updateComponentTreeUI(MainFrame.getInstance().getMyTree());
        }
    }
}
