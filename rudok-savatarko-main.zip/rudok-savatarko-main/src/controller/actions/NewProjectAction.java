package controller.actions;

import controller.commands.NewCommand;
import errorfactory.ErrorType;
import lombok.Getter;
import lombok.Setter;
import model.Presentation;
import model.Project;
import model.RuNodeComposite;
import model.jtree.MyTreeNode;
import view.MainFrame;

import javax.swing.*;
import javax.swing.tree.TreePath;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

@Getter
@Setter

public class NewProjectAction extends AbstractRudokAction{


    public NewProjectAction() {
        putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(ActionEvent.CTRL_MASK, KeyEvent.VK_N));
        putValue(NAME, "New Project");
        putValue(SHORT_DESCRIPTION, "New project");
        putValue(SMALL_ICON, loadIcon("ActionPics/NewProjectAction.png"));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(MainFrame.getInstance().getMyTree().getSelectionModel().getSelectionPath() == null)
        {
            MainFrame.getInstance().getErrorFactory().generateError(ErrorType.noselectionerror);
        }
        MyTreeNode selected = (MyTreeNode)MainFrame.getInstance().getMyTree().getSelectionModel().getSelectionPath().getLastPathComponent();
        String type = selected.getSubType();
        MyTreeNode node = null;


        if (type != null) {

            node = new MyTreeNode(selected.getNode());
            /*
            ((RuNodeComposite)selected.getNode()).addChild(node.getNode());
            ((MyTreeNode) MainFrame.getInstance().getMyTree().getSelectionModel().getSelectionPath().getLastPathComponent()).add(node);
            MainFrame.getInstance().getMyTree().expandPath(new TreePath(selected));
            MainFrame.getInstance().getMyTree().expandPath(new TreePath(((MyTreeNode) MainFrame.getInstance().getMyTree()
                    .getSelectionModel().getSelectionPath().getLastPathComponent()).getLastChild()));

             */
            MainFrame.getInstance().getMyTree().getCommandManager().addCommand(new NewCommand(
                    node, selected
            ));
            //TODO: popraviti da uvek radi
            SwingUtilities.updateComponentTreeUI(MainFrame.getInstance().getMyTree());

        }
        else{
            MainFrame.getInstance().getErrorFactory().generateError(ErrorType.treeslideselection);
        }
        if(type.equals("Slide"))
        {
            MainFrame.getInstance().getProjectView().setProject((Project)((MyTreeNode)((MyTreeNode)MainFrame.getInstance().getMyTree().getLastSelectedPathComponent()).getParent()).getNode(),
                    (Presentation)((MyTreeNode)MainFrame.getInstance().getMyTree().getLastSelectedPathComponent()).getNode());
            MainFrame.getInstance().refresh();
        }
    }
}
