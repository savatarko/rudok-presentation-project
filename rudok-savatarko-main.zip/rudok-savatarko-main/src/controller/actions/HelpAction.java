package controller.actions;

import lombok.Getter;
import lombok.Setter;
import view.HelpFrame;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

@Getter
@Setter

public class HelpAction extends AbstractRudokAction{

    public HelpAction() {
        putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_F2, ActionEvent.CTRL_MASK));
        putValue(SHORT_DESCRIPTION, "Help");
        putValue(NAME, "Help");
        putValue(SMALL_ICON, loadIcon("ActionPics/HelpAction.png"));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        HelpFrame helpFrame = HelpFrame.getInstance();
        helpFrame.setVisible(true);
    }
}
