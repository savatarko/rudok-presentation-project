package controller.actions;

import view.MainFrame;
import view.PresentationView;

import java.awt.event.ActionEvent;

public class RemoveSlotAction extends AbstractRudokAction{
    public RemoveSlotAction() {
        putValue(NAME, "Remove slots");
        putValue(SHORT_DESCRIPTION, "Remove slots");
        putValue(SMALL_ICON, loadIcon("ActionPics/removesloticon.png"));
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        //PresentationView.getSlotStateManager().setRemoveSlotState();
        ((PresentationView)MainFrame.getInstance().getProjectView().getjTabbedPane().getSelectedComponent()).getSlotStateManager().setRemoveSlotState();
        MainFrame.getInstance().getProjectView().update(this);
    }
}
