package controller.actions;

import view.PresentationView;
import view.slot.TextSlotHandler;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

public class TextSlotAction extends AbstractRudokAction{
    public TextSlotAction() {
        putValue(NAME, "Text");
        putValue(SHORT_DESCRIPTION, "Text");
        putValue(SMALL_ICON, loadIcon("ActionPics/textslot.png"));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        PresentationView.getSlot().setSlotHandler(new TextSlotHandler(PresentationView.getSlot()));
    }
}
