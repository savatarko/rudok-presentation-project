package controller.actions;

import view.PresentationView;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class ChangeColorAction extends AbstractRudokAction{
    public ChangeColorAction() {
        putValue(NAME, "Change line color");
        putValue(SHORT_DESCRIPTION, "Change line color");
        putValue(SMALL_ICON, loadIcon("ActionPics/color.png"));
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        JColorChooser jColorChooser = new JColorChooser();
        Color color = jColorChooser.showDialog(null,"yoooooo", PresentationView.getSlot().getColor());
        PresentationView.getSlot().setColor(color);
    }
}
