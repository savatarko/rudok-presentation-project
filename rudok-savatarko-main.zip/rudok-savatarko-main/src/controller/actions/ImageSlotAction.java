package controller.actions;

import view.PresentationView;
import view.slot.MMSlotHandler;
import view.slot.TextSlotHandler;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

public class ImageSlotAction extends AbstractRudokAction{
    public ImageSlotAction() {
        putValue(NAME, "Image");
        putValue(SHORT_DESCRIPTION, "Image");
        putValue(SMALL_ICON, loadIcon("ActionPics/imageslot.png"));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        PresentationView.getSlot().setSlotHandler(new MMSlotHandler(PresentationView.getSlot()));
    }
}
