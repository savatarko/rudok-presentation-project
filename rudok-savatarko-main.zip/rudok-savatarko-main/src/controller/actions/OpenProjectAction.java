package controller.actions;

import model.Project;
import model.RuNodeComposite;
import model.WorkSpace;
import model.jtree.MyTreeNode;
import view.MainFrame;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.event.ActionEvent;
import java.io.*;

public class OpenProjectAction extends AbstractRudokAction{
    public OpenProjectAction() {
        putValue(NAME, "Open project");
        putValue(SHORT_DESCRIPTION, "Open project");
        putValue(SMALL_ICON, loadIcon("ActionPics/open.png"));
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if(!(((MyTreeNode) MainFrame.getInstance().getMyTree().getSelectionModel().getSelectionPath().getLastPathComponent()).getNode() instanceof Project))
            return;//ovde bi mogao neki error da bacis?

        JFileChooser chooser = new JFileChooser();
        chooser = new JFileChooser();
        chooser.setCurrentDirectory(new java.io.File("."));
        chooser.setDialogTitle("Open project");
        chooser.setFileFilter(new FileNameExtensionFilter("Project file", "pro"));

        String path = null;
        if (chooser.showOpenDialog(MainFrame.getInstance()) == JFileChooser.APPROVE_OPTION) {
            path = chooser.getSelectedFile().getPath();
        }
        File file = new File(path);
        ObjectInputStream objectInputStream = null;
        try
        {
            objectInputStream = new ObjectInputStream(new BufferedInputStream(new FileInputStream(file)));
            Project project = (Project)objectInputStream.readObject();
            MyTreeNode myTreeNode = new MyTreeNode(project, "open");
            ((MyTreeNode) MainFrame.getInstance().getMyTree().getModel().getRoot()).add(myTreeNode);
            ((WorkSpace)((MyTreeNode) MainFrame.getInstance().getMyTree().getModel().getRoot()).getNode()).addChild(project);
            SwingUtilities.updateComponentTreeUI(MainFrame.getInstance().getMyTree());
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }
}
