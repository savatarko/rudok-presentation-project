package controller.actions;

import view.ChangeSlotThickness;

import java.awt.event.ActionEvent;

public class ChangeThicknessAction extends AbstractRudokAction{
    public ChangeThicknessAction() {
        putValue(NAME, "Change line thickness");
        putValue(SHORT_DESCRIPTION, "Change line thickness");
        putValue(SMALL_ICON, loadIcon("ActionPics/thickness.png"));
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        ChangeSlotThickness changeSlotThickness = new ChangeSlotThickness();
        changeSlotThickness.show();
    }
}
