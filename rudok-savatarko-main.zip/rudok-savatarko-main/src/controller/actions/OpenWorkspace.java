package controller.actions;

import main.Main;
import model.Project;
import model.RuNodeComposite;
import model.WorkSpace;
import model.jtree.MyTreeNode;
import view.MainFrame;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import java.awt.event.ActionEvent;
import java.io.*;
import java.util.Scanner;

public class OpenWorkspace extends AbstractRudokAction{
    public OpenWorkspace() {
        putValue(NAME, "Open workspace");
        putValue(SHORT_DESCRIPTION, "Open workspace");
        putValue(SMALL_ICON, loadIcon("ActionPics/open.png"));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JFileChooser chooser = new JFileChooser();
        chooser = new JFileChooser();
        chooser.setCurrentDirectory(new java.io.File("." + "/saved"));
        chooser.setDialogTitle("Open workspace");

        chooser.setAcceptAllFileFilterUsed(false);
        chooser.setFileFilter(new FileNameExtensionFilter("Text document", "txt"));



        if (chooser.showOpenDialog(MainFrame.getInstance()) == JFileChooser.APPROVE_OPTION) {
            MainFrame.wspath =  chooser.getSelectedFile().getPath();
            File file = new File(MainFrame.wspath);
            try {
                Scanner scanner = new Scanner(file);
                MyTreeNode workSpace = (MyTreeNode) MainFrame.getInstance().getMyTree().getModel().getRoot();
                workSpace.removeAllChildren();
                MyTreeNode myTreeNode = new MyTreeNode();
                SwingUtilities.updateComponentTreeUI(MainFrame.getInstance().getMyTree());
                while (scanner.hasNext()) {
                    String path = scanner.nextLine();
                    File pfile = new File(path);
                    ObjectInputStream objectInputStream = new ObjectInputStream(new BufferedInputStream(new FileInputStream(pfile)));
                    Project project = (Project) objectInputStream.readObject();
                    //System.out.println(project);
                    myTreeNode = new MyTreeNode(project, "open");
                    ((RuNodeComposite) workSpace.getNode()).addChild(project);
                    workSpace.add(myTreeNode);
                }
                TreePath tre = new TreePath(myTreeNode.getPath());
                MainFrame.getInstance().getMyTree().expandPath(tre);
                SwingUtilities.updateComponentTreeUI(MainFrame.getInstance().getMyTree());
                MainFrame.getInstance().getProjectView().setProject(new Project(""));
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        MainFrame.getInstance().getMyTree().expandRow(0);
    }
}
