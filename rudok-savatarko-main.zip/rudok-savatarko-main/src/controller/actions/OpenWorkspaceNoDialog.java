package controller.actions;

import model.Project;
import model.RuNodeComposite;
import model.jtree.MyTreeNode;
import view.MainFrame;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.event.ActionEvent;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.Scanner;

public class OpenWorkspaceNoDialog extends AbstractRudokAction{
    public OpenWorkspaceNoDialog() {
        putValue(NAME, "Open workspace");
        putValue(SHORT_DESCRIPTION, "Open workspace");
        putValue(SMALL_ICON, loadIcon("ActionPics/open.png"));
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        
            File file = new File(MainFrame.wspath);
            try {
                Scanner scanner = new Scanner(file);
                MyTreeNode workSpace = (MyTreeNode) MainFrame.getInstance().getMyTree().getModel().getRoot();
                workSpace.removeAllChildren();
                SwingUtilities.updateComponentTreeUI(MainFrame.getInstance().getMyTree());
                while (scanner.hasNext()) {
                    String path = scanner.nextLine();
                    File pfile = new File(path);
                    ObjectInputStream objectInputStream = new ObjectInputStream(new BufferedInputStream(new FileInputStream(pfile)));
                    Project project = (Project) objectInputStream.readObject();
                    //System.out.println(project);
                    MyTreeNode myTreeNode = new MyTreeNode(project, "open");
                    ((RuNodeComposite) workSpace.getNode()).addChild(project);
                    workSpace.add(myTreeNode);
                }
                SwingUtilities.updateComponentTreeUI(MainFrame.getInstance().getMyTree());
                MainFrame.getInstance().getProjectView().setProject(new Project(""));

            } catch (Exception ex) {
                ex.printStackTrace();
            }
        MainFrame.getInstance().getMyTree().expandRow(0);
        }
}
