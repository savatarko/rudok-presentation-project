package controller.actions;

import model.Presentation;
import model.Project;
import model.jtree.MyTreeNode;
import view.MainFrame;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class SavePresentationAction extends AbstractRudokAction{
    public SavePresentationAction() {
        putValue(NAME, "Save presentation");
        putValue(SHORT_DESCRIPTION, "Save presentation");
        putValue(SMALL_ICON, loadIcon("ActionPics/save.png"));
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if(!(((MyTreeNode) MainFrame.getInstance().getMyTree().getSelectionModel().getSelectionPath().getLastPathComponent()).getNode() instanceof Presentation))
            return;//ovde bi mogao neki error da bacis?
        Presentation presentation = (Presentation)(((MyTreeNode) MainFrame.getInstance().getMyTree().getSelectionModel().getSelectionPath().getLastPathComponent()).getNode());

        JFileChooser chooser = new JFileChooser();
        chooser = new JFileChooser();
        chooser.setCurrentDirectory(new java.io.File("."));
        chooser.setDialogTitle("Save project");
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        //
        // disable the "All files" option.
        //
        chooser.setAcceptAllFileFilterUsed(false);
        //
        String path = null;
        if (chooser.showOpenDialog(MainFrame.getInstance()) == JFileChooser.APPROVE_OPTION) {
            System.out.println("getCurrentDirectory(): "
                    +  chooser.getCurrentDirectory());
            System.out.println("getSelectedFile() : "
                    +  chooser.getSelectedFile());
            path = chooser.getSelectedFile().getPath();
        }
        File file = new File(path + "\\" + presentation.getName() + ".pst");
        ObjectOutputStream objectOutputStream = null;
        try
        {
            objectOutputStream = new ObjectOutputStream(new FileOutputStream(file));
            objectOutputStream.writeObject(presentation);
            objectOutputStream.close();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }
}
