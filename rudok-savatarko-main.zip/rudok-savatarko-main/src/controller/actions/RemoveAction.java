package controller.actions;

import controller.commands.RemoveCommand;
import errorfactory.ErrorType;
import model.jtree.MyTreeNode;
import view.MainFrame;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

public class RemoveAction extends AbstractRudokAction{

    public RemoveAction() {
        putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(ActionEvent.CTRL_MASK, KeyEvent.VK_DELETE));
        putValue(NAME, "Delete");
        putValue(SHORT_DESCRIPTION, "Delete");
        putValue(SMALL_ICON, loadIcon("ActionPics/delete.png"));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(MainFrame.getInstance().getMyTree().getSelectionModel().getSelectionPath() == null)
            MainFrame.getInstance().getErrorFactory().generateError(ErrorType.noselectionerror);
        MyTreeNode selected = (MyTreeNode) MainFrame.getInstance().getMyTree().getSelectionModel().getSelectionPath().getLastPathComponent();
        String type = selected.getSubType();
        //System.out.println(type);
        /*
        if (type != null) {
            selected.removeAllChildren();
            selected.removeFromParent();
            SwingUtilities.updateComponentTreeUI(MainFrame.getInstance().getMyTree());
        }
        else
        {
            selected.removeFromParent();
            SwingUtilities.updateComponentTreeUI(MainFrame.getInstance().getMyTree());
        }

         */
        MainFrame.getInstance().getMyTree().getCommandManager().addCommand(new RemoveCommand(
                selected, selected, (MyTreeNode)selected.getParent()
        ));
        MainFrame.getInstance().getMyTree().getSelectionModel().clearSelection();
        if(type!=null && type.equals("Presentation"))
        {
            MainFrame.getInstance().getProjectView().removed();
        }
    }
}
