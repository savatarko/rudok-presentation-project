package controller.actions;

import model.jtree.MyTreeNode;
import view.MainFrame;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

public class ShareCopyAction extends AbstractRudokAction{
    public ShareCopyAction() {
        //putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(ActionEvent.CTRL_MASK, KeyEvent.VK_N));
        putValue(NAME, "Share");
        putValue(SHORT_DESCRIPTION, "Share");
        //putValue(SMALL_ICON, loadIcon("ActionPics/NewProjectAction.png"));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        MainFrame.getInstance().setClipboardnode(
                (MyTreeNode)MainFrame.getInstance().getMyTree().getSelectionModel().getSelectionPath().getLastPathComponent()
        );
    }
}
