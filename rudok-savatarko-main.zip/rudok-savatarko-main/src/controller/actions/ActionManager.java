package controller.actions;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ActionManager {

    //URADI OVO OBAVEZNO!!!!

    private ExitAction exitAction;
    private HelpAction helpAction;
    private NewProjectAction newProjectAction;
    private RemoveAction removeAction;
    private ChangePresentationAuthorAction changePresentationAuthorAction;
    private ChangePresentationBgAction changePresentationBgAction;
    private ChangeStateAction changeStateAction;
    private AddSlotAction addSlotAction;
    private RemoveSlotAction removeSlotAction;
    private ChangeThicknessAction changeThicknessAction;
    private ChangeDottedAction changeDottedAction;
    private ChangeColorAction changeColorAction;
    private BoldAction boldAction;
    private ItalicAction italicAction;
    private UnderlineAction underlineAction;
    private RedoAction redoAction;
    private UndoAction undoAction;
    private ShareCopyAction shareCopyAction;
    private SharePasteAction sharePasteAction;
    private TextSlotAction textSlotAction;
    private ImageSlotAction imageSlotAction;
    private SaveWorkspaceAction saveWorkspaceAction;
    private OpenWorkspace openWorkspace;
    private SaveProjectAction saveProjectAction;
    private OpenProjectAction openProjectAction;
    private SavePresentationAction savepresentationAction;
    private OpenPresentationAction openPresentationAction;
    private OpenWorkspaceNoDialog openWorkspaceNoDialog;

    public ActionManager() {
        initialize();
    }
    private void initialize()
    {
        exitAction = new ExitAction();
        helpAction = new HelpAction();
        newProjectAction = new NewProjectAction();
        removeAction = new RemoveAction();
        changePresentationAuthorAction = new ChangePresentationAuthorAction();
        changePresentationBgAction = new ChangePresentationBgAction();
        changeStateAction = new ChangeStateAction();
        addSlotAction = new AddSlotAction();
        removeSlotAction = new RemoveSlotAction();
        changeThicknessAction = new ChangeThicknessAction();
        changeDottedAction = new ChangeDottedAction();
        changeColorAction = new ChangeColorAction();
        boldAction = new BoldAction();
        underlineAction = new UnderlineAction();
        italicAction = new ItalicAction();
        undoAction = new UndoAction();
        redoAction = new RedoAction();
        shareCopyAction = new ShareCopyAction();
        sharePasteAction = new SharePasteAction();
        textSlotAction = new TextSlotAction();
        imageSlotAction = new ImageSlotAction();
        saveWorkspaceAction = new SaveWorkspaceAction();
        openWorkspace = new OpenWorkspace();
        saveProjectAction = new SaveProjectAction();
        openProjectAction = new OpenProjectAction();
        savepresentationAction = new SavePresentationAction();
        openPresentationAction = new OpenPresentationAction();
        openWorkspaceNoDialog = new OpenWorkspaceNoDialog();

        undoAction.setEnabled(false);
        redoAction.setEnabled(false);
    }
}
