package controller.actions;

import view.MainFrame;
import view.PresentationView;

import java.awt.event.ActionEvent;

public class AddSlotAction extends AbstractRudokAction{
    public AddSlotAction() {
        putValue(NAME, "Add slots");
        putValue(SHORT_DESCRIPTION, "Add slots");
        putValue(SMALL_ICON, loadIcon("ActionPics/addsloticon.png"));
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        //PresentationView.getSlotStateManager().setAddSlotState();
        ((PresentationView)MainFrame.getInstance().getProjectView().getjTabbedPane().getSelectedComponent()).getSlotStateManager().setAddSlotState();
        MainFrame.getInstance().getProjectView().update(this);
    }
}
