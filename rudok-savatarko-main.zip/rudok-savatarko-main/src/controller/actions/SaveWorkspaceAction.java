package controller.actions;

import model.WorkSpace;
import model.jtree.MyTreeNode;
import view.MainFrame;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.*;
import java.util.zip.DeflaterOutputStream;

public class SaveWorkspaceAction extends AbstractRudokAction{
    public SaveWorkspaceAction() {
        putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(ActionEvent.CTRL_MASK, KeyEvent.VK_S));
        putValue(NAME, "Save workspace");
        putValue(SHORT_DESCRIPTION, "Save workspace");
        putValue(SMALL_ICON, loadIcon("ActionPics/save.png"));
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        File file = new File("src/workspace/workspace.txt");
        File projectfile;
        ObjectOutputStream objectOutputStream = null;
        ObjectOutputStream pathoutputstream = null;
        PrintWriter pw = null;
        PrintWriter pwf = null;


        String path = null;

        if (e == null) {
            try {
                //pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new DeflaterOutputStream(new FileOutputStream(file)))));
                pw = new PrintWriter(file);
                WorkSpace workSpace = (WorkSpace) ((MyTreeNode) MainFrame.getInstance().getMyTree().getModel().getRoot()).getNode();
                for (var i : workSpace.getChildren()) {
                    projectfile = new File("src/workspace/" + i.getName() + ".pro");
                    objectOutputStream = new ObjectOutputStream(new FileOutputStream(projectfile));
                    objectOutputStream.writeObject(i);

                    pw.println(projectfile.getAbsolutePath().toString());
                    objectOutputStream.close();
                }
                pw.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } else {
            JFileChooser chooser = new JFileChooser();
            chooser = new JFileChooser();
            chooser.setCurrentDirectory(new java.io.File("."));
            chooser.setDialogTitle("Save workspace");
            chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

            chooser.setAcceptAllFileFilterUsed(false);
            if (chooser.showOpenDialog(MainFrame.getInstance()) == JFileChooser.APPROVE_OPTION) {
                path = chooser.getSelectedFile().getPath();
                File selectedfile = new File(path + "\\workspace.txt");

                try {
                    //pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new DeflaterOutputStream(new FileOutputStream(file)))));
                    pw = new PrintWriter(file);
                    pwf = new PrintWriter(selectedfile);
                    WorkSpace workSpace = (WorkSpace) ((MyTreeNode) MainFrame.getInstance().getMyTree().getModel().getRoot()).getNode();
                    for (var i : workSpace.getChildren()) {
                        projectfile = new File("src/workspace/" + i.getName() + ".pro");
                        File pathfile = new File(path + "\\" + i.getName() + ".pro");
                        objectOutputStream = new ObjectOutputStream(new FileOutputStream(projectfile));
                        objectOutputStream.writeObject(i);

                        pathoutputstream = new ObjectOutputStream(new FileOutputStream(pathfile));
                        pathoutputstream.writeObject(i);
                        pw.println(projectfile.getAbsolutePath().toString());
                        pwf.println(pathfile.getAbsolutePath().toString());
                        objectOutputStream.close();
                        pathoutputstream.close();
                    }
                    pw.close();
                    pwf.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }

        /*
        try  {
            //pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new DeflaterOutputStream(new FileOutputStream(file)))));
            pw = new PrintWriter(file);
            WorkSpace workSpace = (WorkSpace)((MyTreeNode)MainFrame.getInstance().getMyTree().getModel().getRoot()).getNode();
            for(var i : workSpace.getChildren())
            {
                projectfile = new File("src/workspace/" + i.getName() + ".pro");
                objectOutputStream = new ObjectOutputStream(new FileOutputStream(projectfile));
                objectOutputStream.writeObject(i);
                pw.println(projectfile.getAbsolutePath().toString());
                objectOutputStream.close();
            }
            pw.close();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }

         */
        }
    }
}
