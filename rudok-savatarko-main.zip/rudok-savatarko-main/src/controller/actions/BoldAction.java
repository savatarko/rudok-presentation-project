package controller.actions;

import view.Toolbar;
import view.slot.JTextEditor;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class BoldAction extends AbstractRudokAction {
    public BoldAction() {
        putValue(NAME, "Bold");
        putValue(SHORT_DESCRIPTION, "Bold");
        putValue(SMALL_ICON, loadIcon("ActionPics/bold.png"));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        /*
        if(JTextEditor.getFontmode().equals("b"))
            JTextEditor.setFontmode("");
        else JTextEditor.setFontmode("b");

         */
        //System.out.println(((JToolBar)e.getSource()).getParent());
        for(var i : Window.getWindows())
        {
            if(i instanceof JTextEditor)
            {
                ((JTextEditor) i).updateFont("b");
            }
        }
    }
}
