package controller.actions;

import java.awt.event.ActionEvent;

public class EditNameAction extends AbstractRudokAction{

    @Override
    public void actionPerformed(ActionEvent e) {
        //MainFrame.getInstance().getMyTree().getCellEditor().isCellEditable();
    }


}
