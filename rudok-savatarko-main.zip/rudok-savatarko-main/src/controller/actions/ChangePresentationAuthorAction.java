package controller.actions;

import model.Presentation;
import model.jtree.MyTreeNode;
import view.ChangePresentationAuthorDialog;
import view.MainFrame;

import java.awt.event.ActionEvent;

public class ChangePresentationAuthorAction extends AbstractRudokAction{

    public ChangePresentationAuthorAction() {
        putValue(NAME, "Change Author");
        putValue(SHORT_DESCRIPTION, "Change Author");
        putValue(SMALL_ICON, loadIcon("ActionPics/Author.jpg"));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(MainFrame.getInstance().getMyTree().getSelectionModel().getSelectionPath() == null)
            return;
        MyTreeNode selected = (MyTreeNode)MainFrame.getInstance().getMyTree().getSelectionModel().getSelectionPath().getLastPathComponent();
        if(selected!=null && selected.getNode() instanceof Presentation)
        {
            ChangePresentationAuthorDialog changePresentationAuthorDialog = new ChangePresentationAuthorDialog((Presentation)selected.getNode());
            changePresentationAuthorDialog.show();
        }
    }
}
