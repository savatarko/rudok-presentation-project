package controller.actions;

import view.PresentationView;

import java.awt.*;
import java.awt.event.ActionEvent;

public class ChangeDottedAction extends AbstractRudokAction{
    public ChangeDottedAction() {
        putValue(NAME, "Change line dot");
        putValue(SHORT_DESCRIPTION, "Change line dot");
        putValue(SMALL_ICON, loadIcon("ActionPics/full.png"));
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        BasicStroke stroke;
        if(PresentationView.getSlot().getStroke().getDashArray() == null)
        {
            float[] dash = {10.0f};
            stroke = new BasicStroke(PresentationView.getSlot().getStroke().getLineWidth(), BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[]{9}, 0);
            putValue(SMALL_ICON, loadIcon("ActionPics/dotted.png"));
        }
        else
        {
            stroke = new BasicStroke(PresentationView.getSlot().getStroke().getLineWidth(), BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL);
            putValue(SMALL_ICON, loadIcon("ActionPics/full.png"));
        }
        System.out.println(PresentationView.getSlot().getStroke().getDashPhase() +" " +  PresentationView.getSlot().getStroke().getDashArray());
        PresentationView.getSlot().setStroke(stroke);
    }
}
