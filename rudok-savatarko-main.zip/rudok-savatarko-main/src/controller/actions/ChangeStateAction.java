package controller.actions;

import view.MainFrame;
import view.PresentationView;

import java.awt.event.ActionEvent;

public class ChangeStateAction extends AbstractRudokAction{
    public ChangeStateAction() {
        putValue(NAME, "Change State");
        putValue(SHORT_DESCRIPTION, "Change State");
        putValue(SMALL_ICON, loadIcon("ActionPics/ChangeState.jpg"));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(MainFrame.getInstance().getProjectView().getjTabbedPane().getSelectedComponent() !=null)
            ((PresentationView)MainFrame.getInstance().getProjectView().getjTabbedPane().getSelectedComponent()).getStateManager().changestate();
    }
}
