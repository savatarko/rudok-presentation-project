package controller.actions;

import view.slot.JTextEditor;

import java.awt.*;
import java.awt.event.ActionEvent;

public class ItalicAction extends AbstractRudokAction{
    public ItalicAction() {
        putValue(NAME, "Italic");
        putValue(SHORT_DESCRIPTION, "Italic");
        putValue(SMALL_ICON, loadIcon("ActionPics/italic.png"));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        for(var i : Window.getWindows())
        {
            if(i instanceof JTextEditor)
            {
                ((JTextEditor) i).updateFont("i");
            }
        }
    }
}
