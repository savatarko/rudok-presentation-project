package controller.actions;

import model.Project;
import model.jtree.MyTreeNode;
import view.MainFrame;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class SaveProjectAction extends AbstractRudokAction{
    public SaveProjectAction() {
        putValue(NAME, "Save project");
        putValue(SHORT_DESCRIPTION, "Save project");
        putValue(SMALL_ICON, loadIcon("ActionPics/save.png"));
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if(!(((MyTreeNode) MainFrame.getInstance().getMyTree().getSelectionModel().getSelectionPath().getLastPathComponent()).getNode() instanceof Project))
            return;//ovde bi mogao neki error da bacis?
        Project project = (Project)(((MyTreeNode) MainFrame.getInstance().getMyTree().getSelectionModel().getSelectionPath().getLastPathComponent()).getNode());

        JFileChooser chooser = new JFileChooser();
        chooser = new JFileChooser();
        chooser.setCurrentDirectory(new java.io.File("."));
        chooser.setDialogTitle("Save project");
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        //
        // disable the "All files" option.
        //
        chooser.setAcceptAllFileFilterUsed(false);
        //
        String path = null;
        if (chooser.showOpenDialog(MainFrame.getInstance()) == JFileChooser.APPROVE_OPTION) {

            path = chooser.getSelectedFile().getPath();
            File file = new File(path + "\\" + project.getName() + ".pro");
            ObjectOutputStream objectOutputStream = null;
            try
            {
                objectOutputStream = new ObjectOutputStream(new FileOutputStream(file));
                objectOutputStream.writeObject(project);
                objectOutputStream.close();
            }
            catch (Exception ex)
            {
                ex.printStackTrace();
            }
        }
    }
}
