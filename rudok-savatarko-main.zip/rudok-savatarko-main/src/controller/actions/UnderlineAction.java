package controller.actions;

import view.slot.JTextEditor;

import java.awt.*;
import java.awt.event.ActionEvent;

public class UnderlineAction extends AbstractRudokAction{
    public UnderlineAction() {
        putValue(NAME, "Underline");
        putValue(SHORT_DESCRIPTION, "Underline");
        putValue(SMALL_ICON, loadIcon("ActionPics/underline.png"));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        for(var i : Window.getWindows())
        {
            if(i instanceof JTextEditor)
            {
                ((JTextEditor) i).updateFont("u");
            }
        }
    }
}
