package controller.actions;

import model.Presentation;
import model.Project;
import model.RuNodeComposite;
import model.jtree.MyTreeNode;
import view.MainFrame;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.event.ActionEvent;
import java.io.*;

public class OpenPresentationAction extends AbstractRudokAction{
    public OpenPresentationAction() {
        putValue(NAME, "Open presentation");
        putValue(SHORT_DESCRIPTION, "Open presentation");
        putValue(SMALL_ICON, loadIcon("ActionPics/open.png"));
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if(!(((MyTreeNode) MainFrame.getInstance().getMyTree().getSelectionModel().getSelectionPath().getLastPathComponent()).getNode() instanceof Project))
            return;//ovde bi mogao neki error da bacis?
        MyTreeNode node = (((MyTreeNode) MainFrame.getInstance().getMyTree().getSelectionModel().getSelectionPath().getLastPathComponent()));

        JFileChooser chooser = new JFileChooser();
        chooser = new JFileChooser();
        chooser.setCurrentDirectory(new java.io.File("."));
        chooser.setDialogTitle("Open project");
        chooser.setFileFilter(new FileNameExtensionFilter("Presentation file", "pst"));

        String path = null;
        if (chooser.showOpenDialog(MainFrame.getInstance()) == JFileChooser.APPROVE_OPTION) {
            path = chooser.getSelectedFile().getPath();
        }
        File file = new File(path);
        ObjectInputStream objectInputStream = null;
        try
        {
            objectInputStream = new ObjectInputStream(new BufferedInputStream(new FileInputStream(file)));
            Presentation presentation = (Presentation) objectInputStream.readObject();
            presentation.setParent(node.getNode());
            MyTreeNode myTreeNode = new MyTreeNode(presentation, "open");
            node.add(myTreeNode);
            ((RuNodeComposite)node.getNode()).addChild(presentation);
            SwingUtilities.updateComponentTreeUI(MainFrame.getInstance().getMyTree());
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }
}
