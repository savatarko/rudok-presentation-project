package controller.commands;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import model.Presentation;
import model.RuNodeComposite;
import model.Slide;
import model.jtree.MyTreeNode;
import view.MainFrame;

import javax.swing.*;
import javax.swing.tree.TreePath;
import java.util.ArrayList;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
public class RemoveCommand extends AbstractCommand{
    private MyTreeNode node;
    private MyTreeNode parent;
    private MyTreeNode selected;
    private List<MyTreeNode> shared = new ArrayList<>();

    @Override
    public void doCommand() {
        shared.clear();
        if(node.getNode() instanceof Presentation)
        {
            if(((MyTreeNode)node.getParent()).getNode() == node.getNode().getParent())
            {
                if(((Presentation) node.getNode()).getShared() !=null)
                for(var i : ((Presentation) node.getNode()).getShared())
                {
                    i.removeFromParent();
                }
            }
        }
        /*
        if(node.getNode() instanceof Slide)
        {
            for(var i : ((Presentation)selected.getNode()).getShared())
            {

            }
        }

         */
        node.removeFromParent();
        //selected = (MyTreeNode)node.getParent();
        SwingUtilities.updateComponentTreeUI(MainFrame.getInstance().getMyTree());

    }

    @Override
    public void undoCommand() {
        //selected = (MyTreeNode)node.getParent();
        ((RuNodeComposite) selected.getNode()).addChild(node.getNode());
        selected.add(node);
        (node.getNode()).getParent().notifySubscribers(this); //OVA LINIJA PRAVI PROBLEM!!!!
        MainFrame.getInstance().getMyTree().expandPath(new TreePath(selected));

        /*
        if(selected.getNode() instanceof Presentation)
        {
            for(var i : ((Presentation) selected.getNode()).getShared())
            {
                MyTreeNode myTreeNode = new MyTreeNode(selected.getNode());
                i.add(myTreeNode);
                shared.add(myTreeNode);
            }
        }

         */
        SwingUtilities.updateComponentTreeUI(MainFrame.getInstance().getMyTree());

    }

    public RemoveCommand(MyTreeNode node) {
        this.node = node;

    }

    public RemoveCommand(MyTreeNode node, MyTreeNode parent, MyTreeNode selected) {
        this.node = node;
        this.parent = parent;
        this.selected = selected;
    }
}
