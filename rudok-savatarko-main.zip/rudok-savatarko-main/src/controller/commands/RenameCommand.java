package controller.commands;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import model.jtree.MyTreeNode;
import view.MainFrame;

import javax.swing.*;

@AllArgsConstructor
@NoArgsConstructor

public class RenameCommand extends AbstractCommand{
    private MyTreeNode node;
    private String newname;
    private String oldname;
    @Override
    public void doCommand() {
        node.getNode().setName(newname);
        ((MyTreeNode)node.getParent()).getNode().notifySubscribers(node);
        SwingUtilities.updateComponentTreeUI(MainFrame.getInstance().getMyTree());
    }

    @Override
    public void undoCommand() {
        node.getNode().setName(oldname);
        ((MyTreeNode)node.getParent()).getNode().notifySubscribers(node);
        SwingUtilities.updateComponentTreeUI(MainFrame.getInstance().getMyTree());

    }
}
