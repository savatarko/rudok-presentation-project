package controller.commands;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import model.Presentation;
import model.RuNodeComposite;
import model.jtree.MyTreeNode;
import view.MainFrame;

import javax.swing.*;
import javax.swing.tree.TreePath;
import java.util.ArrayList;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor

public class NewCommand extends AbstractCommand{
    private MyTreeNode node;
    private MyTreeNode selected;
    private List<MyTreeNode>shared = new ArrayList<>();

    @Override
    public void doCommand() {
        if(selected.getNode() instanceof RuNodeComposite)
        {
            shared.clear();
            ((RuNodeComposite) selected.getNode()).addChild(node.getNode());
            selected.add(node);
            (node.getNode()).getParent().notifySubscribers(this); //OVA LINIJA PRAVI PROBLEM!!!!

            if(selected.getNode() instanceof Presentation)
            {
                for(var i : ((Presentation) selected.getNode()).getShared())
                {
                    MyTreeNode myTreeNode = new MyTreeNode(selected.getNode());
                    if(selected !=i) {
                        i.add(myTreeNode);
                        shared.add(myTreeNode);
                    }
                }
            }

            MainFrame.getInstance().getMyTree().expandPath(new TreePath(selected));
            SwingUtilities.updateComponentTreeUI(MainFrame.getInstance().getMyTree());
        }
    }

    @Override
    public void undoCommand() {
        //if(node.getSubType() !=null)
        {
            node.removeFromParent();
            if(selected.getNode() instanceof Presentation)
            {
                for(var i : shared)
                {
                    i.removeFromParent();
                    //SwingUtilities.updateComponentTreeUI(MainFrame.getInstance().getMyTree());
                }
            }
            SwingUtilities.updateComponentTreeUI(MainFrame.getInstance().getMyTree());
        }
    }

    public NewCommand(MyTreeNode node, MyTreeNode selected) {
        this.node = node;
        this.selected = selected;
    }
}
