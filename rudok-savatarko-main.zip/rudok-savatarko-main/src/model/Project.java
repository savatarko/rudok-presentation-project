package model;

import lombok.Getter;
import lombok.Setter;
import model.jtree.MyTreeNode;
import observer.Subscriber;
import view.ProjectView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Setter
@Getter

public class Project extends RuNodeComposite{

    private transient Subscriber projectViewSubs;

    public Project(String s) {
        name = s;
    }


    @Override
    public void addChild(Object o) {
        if(o instanceof Presentation)
        {
            super.addChild(o);
        }
    }




    @Override
    public void removeChild(Object o) {
        if(o instanceof MyTreeNode)
        {
            if(((MyTreeNode) o).getNode() instanceof Presentation)
            {
                children.remove(((MyTreeNode) o).getNode());
                if(projectViewSubs!=null)
                    notifySubscribers(this);
            }
        }
    }



    @Override
    public void notifySubscribers(Object notification) {
        if(projectViewSubs!=null)
            projectViewSubs.update(this);
    }

    @Override
    public void removeSubscriber(Subscriber sub) {

    }

    @Override
    public void addSubscriber(Subscriber sub) {
        /*
        if(sub instanceof ProjectView)
        {
            if(projectViewSubs == null)
            {
                projectViewSubs = new ArrayList<>();
            }
            projectViewSubs.add(sub);
        }

         */
        projectViewSubs = sub;
    }

    @Override
    public void update(Object notification) {
    }
}
