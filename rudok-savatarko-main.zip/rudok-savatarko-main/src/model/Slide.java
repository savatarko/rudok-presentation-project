package model;

import lombok.Getter;
import lombok.Setter;
import observer.Publisher;
import observer.Subscriber;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class Slide extends RuNode implements Publisher {
    private int slidenumber;
    private List<Slot>slotList = new ArrayList<>();
    private transient List<Subscriber> subs = new ArrayList<>();

    public Slide(int number) {
        this.slidenumber = number;
    }

    public Slide() {

    }

    public Slide(String name) {
        super(name);
    }

    @Override
    public void notifySubscribers(Object notification) {
        for(var i : subs)
            i.update(this);
    }

    @Override
    public void removeSubscriber(Subscriber sub) {
        subs.remove(sub);
    }

    @Override
    public void addSubscriber(Subscriber sub) {
        if(subs == null)
            subs = new ArrayList<>();
        subs.add(sub);
    }

    @Override
    public void update(Object notification) {

    }

    public void addSlot(Slot slot)
    {
        slotList.add(0,slot);
        notifySubscribers(this);
    }

    public void removeSlot(Slot slot)
    {
        slotList.remove(slot);
        notifySubscribers(this);
    }

    public void changeslot(Slot slot)
    {

    }
}
