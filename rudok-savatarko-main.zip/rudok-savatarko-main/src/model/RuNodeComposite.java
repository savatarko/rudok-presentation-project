package model;

import lombok.Getter;
import lombok.Setter;
import observer.Subscriber;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter

public abstract class RuNodeComposite extends RuNode{
    List<RuNode> children;
    protected transient List<Subscriber> subscribers = new ArrayList<>();
    protected transient List<Subscriber> publishers = new ArrayList<>();

    public RuNodeComposite() {
        children = new ArrayList<>();
    }
    public void addChild(Object o) {
        if(children == null)
            children = new ArrayList<>();
        children.add((RuNode) o);
        if(subscribers!=null)
            notifySubscribers(this);
    }

    //public abstract void addChild(Object o);
    //public abstract void removeChild(Object o);
    public void removeChild(Object o)
    {
        children.remove(o);
        if(children!=null)
        notifySubscribers(this);
    }
    public void removeAllChildren()
    {
        children.removeAll(children);
    }

    public RuNodeComposite(String name) {
        super(name);
    }

    public List<RuNode> getChildren() {
        if(children == null)
            children = new ArrayList<>();
        return children;
    }
}
