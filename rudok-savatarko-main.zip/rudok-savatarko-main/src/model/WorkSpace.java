package model;

import observer.Subscriber;

import java.io.Serializable;
import java.util.ArrayList;

public class WorkSpace extends RuNodeComposite {


    @Override
    public void addChild(Object o) {
        if(o instanceof Project) {
            super.addChild(o);
        }
    }



    /*
    @Override
    public void removeChild(Object o) {
        children.remove(o);
    }

     */

    public WorkSpace(String name) {
        super(name);
    }

    @Override
    public void notifySubscribers(Object notification) {

    }

    @Override
    public void removeSubscriber(Subscriber sub) {

    }

    @Override
    public void addSubscriber(Subscriber sub) {

    }

    @Override
    public void update(Object notification) {

    }
}
