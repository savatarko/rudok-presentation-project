package model.jtree;

import controller.commands.CommandManager;
import controller.listeners.MyMouseListener;
import lombok.Getter;

import javax.swing.*;
import javax.swing.tree.DefaultTreeCellRenderer;
@Getter

public class MyTree extends JTree {

    MyMouseListener myMouseListener = new MyMouseListener();

    private CommandManager commandManager = new CommandManager();
    public MyTree() {
        //setModel(new MyTreeModel());
        addTreeSelectionListener(new MyTreeSelectionListener());
        setCellEditor(new MyTreeCellEditor(this, new DefaultTreeCellRenderer()));
        setCellRenderer(new MyTreeCellRendered());
        setEditable(true);
        addMouseListener(myMouseListener);
        this.setToggleClickCount(0);
    }

    public void addNode(MyTreeNode myTreeNode)
    {
        ((MyTree)getModel()).addNode(myTreeNode);
        SwingUtilities.updateComponentTreeUI(this);
        //this.getSelectionModel().get
    }

    public void removeNode(MyTreeNode myTreeNode)
    {
        ((MyTree)getModel()).addNode(myTreeNode);
        SwingUtilities.updateComponentTreeUI(this);
    }

}
