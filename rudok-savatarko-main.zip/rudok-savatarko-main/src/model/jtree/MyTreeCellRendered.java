package model.jtree;

import model.Presentation;
import model.Project;
import model.Slide;

import javax.swing.*;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.TreeCellRenderer;
import java.awt.*;
import java.net.URL;

public class MyTreeCellRendered extends DefaultTreeCellRenderer {


    @Override
    public Component getTreeCellRendererComponent(JTree tree, Object value, boolean selected, boolean expanded, boolean leaf, int row, boolean hasFocus) {
        super.getTreeCellRendererComponent(tree,value,selected,expanded,leaf,row,hasFocus);
        if(value instanceof MyTreeNode) {

            if (((MyTreeNode) value).getNode() instanceof Project) {
                URL imageURL = getClass().getResource("images/project.jpg");
                Icon icon = null;
                if (imageURL != null)
                    icon = new ImageIcon(imageURL);
                setIcon(icon);
            } else if (((MyTreeNode) value).getNode() instanceof Presentation) {
                URL imageURL = getClass().getResource("images/presentation.jpg");
                Icon icon = null;
                if (imageURL != null)
                    icon = new ImageIcon(imageURL);
                setIcon(icon);
            } else if (((MyTreeNode) value).getNode() instanceof Slide) {
                URL imageURL = getClass().getResource("images/slide.jpg");
                Icon icon = null;
                if (imageURL != null)
                    icon = new ImageIcon(imageURL);
                setIcon(icon);
            }
        }
        return this;
    }
}
