package model.jtree;

import controller.commands.RenameCommand;
import errorfactory.ErrorType;
import model.RuNode;
import observer.Publisher;
import observer.Subscriber;
import view.MainFrame;

import javax.swing.*;
import javax.swing.event.CellEditorListener;
import javax.swing.tree.DefaultTreeCellEditor;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.TreeCellEditor;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.EventObject;
import java.util.List;


public class MyTreeCellEditor extends DefaultTreeCellEditor implements ActionListener, Publisher {

    private JTextField edit = null;
    private Object stavka;
    private List<Subscriber> subscribers;

    public MyTreeCellEditor(JTree tree, DefaultTreeCellRenderer renderer) {
        super(tree, renderer);
    }

    @Override
    public Component getTreeCellEditorComponent(JTree tree, Object value, boolean isSelected, boolean expanded, boolean leaf, int row) {
        stavka = value;
        edit = new JTextField(value.toString());
        edit.addActionListener(this);
        return edit;
    }

    public boolean isCellEditable(EventObject arg0) {
        if (arg0 instanceof MouseEvent)
            return ((MouseEvent) arg0).getClickCount() == 3;
        return false;
    }


    public void actionPerformed(ActionEvent e) {
        if(e.getActionCommand().equals(""))
        {
            MainFrame.getInstance().getErrorFactory().generateError(ErrorType.renamenullerror);
            //System.out.println("passed");
        }
        /*
        ((MyTreeNode)stavka).getNode().setName(e.getActionCommand());
        ((MyTreeNode) ((MyTreeNode) stavka).getParent()).getNode().notifySubscribers(stavka);

         */
        MainFrame.getInstance().getMyTree().getCommandManager().addCommand(new RenameCommand(
                (MyTreeNode)stavka, e.getActionCommand(), ((MyTreeNode) stavka).getNode().getName()
        ));
    }

    @Override
    public void notifySubscribers(Object notification) {
        for(var i : subscribers)
        {
            i.update(notification);
        }
    }

    @Override
    public void removeSubscriber(Subscriber sub) {
        subscribers.remove(sub);
    }

    @Override
    public void addSubscriber(Subscriber sub) {
        if(subscribers == null)
        {
            subscribers = new ArrayList<>();
        }
        subscribers.add(sub);
    }
}
