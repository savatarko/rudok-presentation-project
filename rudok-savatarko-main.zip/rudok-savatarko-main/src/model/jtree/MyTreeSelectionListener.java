package model.jtree;

import observer.Publisher;
import observer.Subscriber;

import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.TreePath;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.EventListener;

public class MyTreeSelectionListener implements TreeSelectionListener, Publisher, ActionListener {
    private MyTreeNode selectedNode = null;
    @Override
    public void valueChanged(TreeSelectionEvent e) {
        TreePath path = e.getPath();
        selectedNode = (MyTreeNode)path.getLastPathComponent();
        for (int i = 0; i < path.getPathCount(); i++) {
            if (path.getPathComponent(i) instanceof MyTreeNode) {
                MyTreeNode d = (MyTreeNode) path.getPathComponent(i);
                /*
                System.out.println("Selektovan dijagram:" + d);

                System.out.println("getPath: " + e.getPath());
                System.out.println("getPath: " + e.getNewLeadSelectionPath());

                 */
                break;
            }
        }
    }

    public MyTreeNode getSelectedNode() {
        return selectedNode;
    }

    @Override
    public void notifySubscribers(Object notification) {

    }

    @Override
    public void removeSubscriber(Subscriber sub) {

    }

    @Override
    public void addSubscriber(Subscriber sub) {

    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }

}
