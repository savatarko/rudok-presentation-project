package model.jtree;

import javax.swing.event.TreeModelListener;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;

public class MyTreeModel extends DefaultTreeModel {


    public MyTreeModel() {
        super(new MyTreeNode("Workspace"));
    }
    public void addNode(MyTreeNode myTreeNode)
    {
        ((MyTree)getRoot()).addNode(myTreeNode);
    }
    public void removeNode(MyTreeNode myTreeNode)
    {
        ((MyTree)getRoot()).removeNode(myTreeNode);
    }
}
