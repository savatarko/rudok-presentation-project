package model.jtree;

import factory.RuNodeFactory;
import lombok.Getter;
import lombok.Setter;
import model.*;
import observer.Subscriber;

import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreeNode;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Locale;
import java.util.Objects;

@Getter
@Setter
public class MyTreeNode extends DefaultMutableTreeNode implements Subscriber {
    RuNode node;
    public MyTreeNode() {
        super();
    }
    public MyTreeNode(String type)
    {
        super();
        if(type.toUpperCase().equals("WORKSPACE"))
    {
        node = new WorkSpace("Workspace");
    }
}
/*
    public MyTreeNode(String type, String name)
    {
        super();
        //ovde ubaciti factory
        /*
        if(type.toUpperCase().equals("PROJECT"))
        {
            node = new Project(name);
        }
        else if(type.toUpperCase().equals("SLIDE"))
        {
            node = new Slide(name);
        }
        else if(type.toUpperCase().equals("PRESENTATION"))
        {
            node = new Presentation(name);
        }


        node = RuNodeFactory.getFactory(type,type);
    }
    */

    public MyTreeNode(RuNode node) {
        super();
        this.node = RuNodeFactory.getFactory(node).createRuNode(node);
        /*
        if(node instanceof Presentation && ((Presentation) node).getShared().size() == 0)
        {
            ((Presentation) node).addshare(this);
        }

         */
    }

    public MyTreeNode(RuNode node, String share)
    {
        super();
        this.node = node;
        if(node instanceof Presentation)
        {
            ((Presentation) node).setShared(new ArrayList<>());
        }
        if(node instanceof RuNodeComposite)
        {
            for(var i : ((RuNodeComposite) node).getChildren())
            {
                this.add(new MyTreeNode(i ,"open"));
            }
        }
    }

    @Override
    public String toString() {
        if(node!=null) {
            //return node.getName();
            if(node instanceof Presentation)
            {
                if(node.getParent() != ((MyTreeNode)this.getParent()).getNode())
                {
                    return node.getName() + " (shared)";
                }
                else return node.getName();
            }
            else return node.getName();
        }
        else return null;
    }

    public String getSubType()
    {
        if(this.getNode() ==null)
            return null;
        if(this.getNode().getClass() == WorkSpace.class)
            return "Project";
        if(this.getNode().getClass() == Project.class)
            return "Presentation";
        if(this.getNode().getClass() == Presentation.class)
            return "Slide";
        return null;
    }
    @Override
    public void removeAllChildren() {
        if (children != null) {
            if (!(this.getNode() instanceof Slide)) {
                ((RuNodeComposite) this.getNode()).removeAllChildren();
            }
            for (int i = getChildCount() - 1; i >= 0; i--) {
                remove(i);
            }
        }
    }

    @Override
    public void removeFromParent() {
        MutableTreeNode parent = (MutableTreeNode)getParent();
        if (parent != null) {
            if(parent instanceof MyTreeNode && ((MyTreeNode) parent).getNode() instanceof RuNodeComposite) {
                ((RuNodeComposite) ((MyTreeNode) parent).getNode()).removeChild(this);
            }
            this.getNode().notifySubscribers(this.getNode());
            parent.remove(this);
            this.getNode().getParent().notifySubscribers(this);
        }
    }

    @Override
    public void update(Object notification) {

    }
}