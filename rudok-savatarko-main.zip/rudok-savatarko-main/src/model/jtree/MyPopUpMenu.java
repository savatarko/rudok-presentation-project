package model.jtree;

import view.MainFrame;

import javax.swing.*;

public class MyPopUpMenu extends JPopupMenu {
    private JMenuItem item1;
    private JMenuItem item2;

    public MyPopUpMenu() {
        item1 = new JMenuItem(MainFrame.getInstance().getActionManager().getShareCopyAction());
        item2 = new JMenuItem(MainFrame.getInstance().getActionManager().getSharePasteAction());
        add(item1);
        add(item2);
    }
}
