package model;

import lombok.Getter;
import lombok.Setter;
import model.jtree.MyTreeNode;
import observer.Subscriber;
import view.PresentationView;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter


public class Presentation extends RuNodeComposite implements Cloneable{
    private String author = "User";
    private String backgroundImagePath = "src/view/slideBackgrounds/default.jpg";
    private transient List<Subscriber> presentationViewSubs = new ArrayList<>();
    //private boolean shared = false;
    private transient List<MyTreeNode> shared = new ArrayList<>();

    public Presentation() {
    }
    public Presentation(Presentation presentation)
    {
        //iskreno nzm, ideja je ako se deli da ima sve parametre al nzm kako cu odraditi ovo iskreno
        //this.shared = true;
        author = presentation.author;
        backgroundImagePath = presentation.backgroundImagePath;
        presentationViewSubs = presentation.presentationViewSubs;
        /*
        try {
            this =(Presentation) presentation.clone();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

         */
    }

    public void addshare(MyTreeNode myTreeNode)
    {
        shared.add(myTreeNode);
    }

    public Presentation(String name) {
        super(name);
    }


    public void copyPresentation(Presentation source)
    {
        author = source.author;
        backgroundImagePath = source.backgroundImagePath;
        children = source.children;
        name = source.name;
        parent = source.parent;
        subscribers = source.subscribers;
        publishers = source.publishers;
    }


    @Override
    public void addChild(Object o) {
        if(o instanceof Slide) {
            super.addChild(o);
        }
    }




    @Override
    public void removeChild(Object o) {
        if(o instanceof MyTreeNode)
            children.remove(((MyTreeNode) o).getNode());
        if(presentationViewSubs!=null)
        notifySubscribers(o);
    }



    public Presentation(String author, String backgroundImagePath) {
        this.author = author;
        this.backgroundImagePath = backgroundImagePath;
    }

    @Override
    public void notifySubscribers(Object notification) {
        if(presentationViewSubs != null)
        for(var i : presentationViewSubs)
        {
            i.update(this);
        }
    }

    @Override
    public void removeSubscriber(Subscriber sub) {
        presentationViewSubs.remove(sub);
    }

    @Override
    public void addSubscriber(Subscriber sub) {
        if(presentationViewSubs == null)
        {
            presentationViewSubs = new ArrayList<>();
        }
        presentationViewSubs.add(sub);
    }

    @Override
    public void update(Object notification) {

    }

    public void setAuthor(String author) {
        this.author = author;
        notifySubscribers(this);
    }

    public void setBackgroundImagePath(String backgroundImagePath) {
        this.backgroundImagePath = backgroundImagePath;
        notifySubscribers(this);
    }
}
