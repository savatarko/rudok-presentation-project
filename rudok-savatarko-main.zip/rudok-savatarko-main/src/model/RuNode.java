package model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import observer.Publisher;
import observer.Subscriber;

import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public abstract class RuNode implements Publisher, Subscriber, Serializable {
    String name;
    RuNode parent;

    public RuNode(String name) {
        this.name = name;
    }

    public void setParent(RuNode parent) {
        this.parent = parent;
    }
}
