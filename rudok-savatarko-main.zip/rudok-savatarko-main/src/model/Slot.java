package model;

import lombok.Getter;
import lombok.Setter;
import observer.Publisher;
import observer.Subscriber;
import view.slot.MMSlotHandler;
import view.slot.SlotContent;
import view.slot.SlotHandler;
import view.slot.TextSlotHandler;

import java.awt.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Getter
@Setter
public class Slot implements Serializable {
    private double x;
    private double y;
    private double width;
    private double height;
    private Color color;
    private transient BasicStroke stroke;
    //private SlotContent slotContent;
    private SlotHandler slotHandler;

    private List<Subscriber> subs = new ArrayList<>();

    public void setStroke(BasicStroke stroke) {
        this.stroke = new BasicStroke(5, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER);

    }

    public Slot() {
        color = Color.WHITE;
        x = 0;
        y = 0;
        width = 0.25;
        height = 0.3;
        stroke = new BasicStroke(5, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER);
        slotHandler = new TextSlotHandler(this);
    }

    public Slot(Slot s) {
        color = s.color;
        stroke = s.stroke;
        width = s.width;
        height = s.height;
        if(s.slotHandler instanceof TextSlotHandler)
            slotHandler = new TextSlotHandler(this);
        else slotHandler = new MMSlotHandler(this);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Slot slot = (Slot) o;
        return x == slot.x && y == slot.y && width == slot.width && height == slot.height && Objects.equals(color, slot.color) && Objects.equals(stroke, slot.stroke);
    }

    @Override
    public int hashCode() {
        return Objects.hash(x, y, width, height, color, stroke);
    }
}
