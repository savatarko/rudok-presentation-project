package factory;

import model.*;

public abstract class RuNodeFactory {
    public abstract RuNode createRuNode(RuNode parent);
    public static RuNodeFactory getFactory(RuNode parent)
    {
        RuNode node = null;
        if(parent.getClass() == WorkSpace.class)
        {
            return new ProjectFactory();
        }
        else if(parent.getClass() == Project.class)
        {
            return new PresentationFactory();
        }
        else if(parent.getClass() == Presentation.class)
        {
            return new SlideFactory();
        }
        //ovde neki exception vrv??
        else return null;
    }
}
