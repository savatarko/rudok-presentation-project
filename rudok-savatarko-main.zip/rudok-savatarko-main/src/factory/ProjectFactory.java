package factory;

import model.Presentation;
import model.Project;
import model.RuNode;
import model.RuNodeComposite;

public class ProjectFactory extends RuNodeFactory{
    @Override
    public RuNode createRuNode(RuNode parent) {
        String name = "Project " + (((RuNodeComposite)parent).getChildren().size() + 1);
        RuNode ruNode = new Project(name);
        ruNode.setParent(parent);
        return ruNode;
    }
}
