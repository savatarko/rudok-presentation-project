package factory;

import model.Presentation;
import model.RuNode;
import model.RuNodeComposite;

public class PresentationFactory extends RuNodeFactory{

    @Override
    public RuNode createRuNode(RuNode parent) {
        String name = "Presentation " + (((RuNodeComposite)parent).getChildren().size() + 1);
        RuNode ruNode = new Presentation(name);
        ruNode.setParent(parent);
        return ruNode;
    }
}
