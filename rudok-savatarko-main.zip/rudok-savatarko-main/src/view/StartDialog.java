package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class StartDialog extends JDialog {
    private JButton newbutton;
    private JButton recentbutton;
    private JButton openbutton;

    public StartDialog() {
        initialize();
    }
    private void initialize()
    {
        newbutton = new JButton();
        recentbutton = new JButton();
        openbutton = new JButton();
        recentbutton.setAction(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                MainFrame.getInstance().getActionManager().getOpenWorkspaceNoDialog().actionPerformed(null);
                StartDialog.this.dispose();
            }
        });
        openbutton.setAction(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                MainFrame.getInstance().getActionManager().getOpenWorkspace().actionPerformed(null);
                StartDialog.this.dispose();
            }
        });
        newbutton.setAction(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                StartDialog.this.dispose();
            }
        });

        newbutton.setText("New Workspace");
        recentbutton.setText("Last workspace");
        openbutton.setText("Open workspace");
        this.setLayout(new GridLayout(3,1));
        this.add(newbutton);
        this.add(recentbutton);
        this.add(openbutton);
        this.setSize(new Dimension(500,400));
        this.setLocationRelativeTo(MainFrame.getInstance());
        this.toFront();
    }
}
