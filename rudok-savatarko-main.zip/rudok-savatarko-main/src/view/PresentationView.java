package view;

import model.Presentation;
import model.Slide;
import model.Slot;
import observer.Subscriber;
import view.presentationstate.StateManager;
import view.slotstate.SlotStateManager;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class PresentationView extends JPanel implements Subscriber {
    private List<Slide> slides;
    private Presentation presentation;
    private Label namelabel;
    private Label authorlabel;
    private JPanel panel;
    private JScrollPane jScrollPane = new JScrollPane();
    JScrollBar jScrollBar;
    int scroll = 0;
    static int w = 0, h = 0;


    private StateManager stateManager = new StateManager(this);
    //private static SlotStateManager slotStateManager = new SlotStateManager();
    private SlotStateManager slotStateManager = new SlotStateManager();

    private static Slot slot = new Slot();

    public PresentationView(Presentation presentation) {
        this.presentation = presentation;
        initialize();
    }
    private void initialize()
    {
        JPanel jPanel = new JPanel();
        jPanel.setLayout(new BorderLayout());
        this.setLayout(new BorderLayout());
        this.removeAll();


        this.add(stateManager.getCurrentState().draw(presentation), BorderLayout.CENTER);
        validate();
        repaint();
        MainFrame.getInstance().refresh();
    }
    public void addSlide(SlideView slideView)
    {
        panel.add(Box.createVerticalStrut(15));
        panel.add(slideView);
        panel.add(Box.createVerticalStrut(15));
    }

    @Override
    public void update(Object notification) {
        /*
        scroll =  jScrollPane.getVerticalScrollBar().getValue();
        presentation = (Presentation) notification;

         */
        w=this.getWidth();
        h=this.getHeight();
        initialize();
        validate();
        repaint();
        MainFrame.getInstance().getProjectView().validate();
        MainFrame.getInstance().getProjectView().repaint();
        for(var i : presentation.getChildren())
        {
            ((Slide)i).notifySubscribers(this);
        }
        /*
        revalidate();
        repaint();

         */
        MainFrame.getInstance().refresh();
    }

    public StateManager getStateManager() {
        return stateManager;
    }

        /*
    public static SlotStateManager getSlotStateManager() {
        return slotStateManager;
    }

         */



    public SlotStateManager getSlotStateManager() {
        return slotStateManager;
    }



    public static Slot getSlot() {
        return slot;
    }

    public Presentation getPresentation() {
        return presentation;
    }

    public static int getW() {
        return w;
    }

    public static int getH() {
        return h;
    }
}
