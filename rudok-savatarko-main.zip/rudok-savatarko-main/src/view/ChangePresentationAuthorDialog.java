package view;

import model.Presentation;
import model.RuNodeComposite;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class ChangePresentationAuthorDialog extends JDialog {
    private JTextField nametf;
    private JButton jButton;

    public ChangePresentationAuthorDialog(Presentation presentation) {
        initialize(presentation);
    }
    private void initialize(Presentation p) {
        nametf = new JTextField(p.getAuthor());
        jButton = new JButton("Confirm");
        //this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        JPanel jPanel = new JPanel();
        GridLayout gridLayout = new GridLayout(2,2);
        jButton.setText("Confirm");
        jPanel.setLayout(gridLayout);
        jPanel.add(nametf);
        jPanel.add(jButton);
        setLocationRelativeTo(MainFrame.getInstance());
        this.add(jPanel);
        this.setSize(new Dimension(300,200));
        jButton.setAction(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                p.setAuthor(nametf.getText());
                dispose();
            }
        });
    }
}
