package view.slotstate;

import view.MainFrame;

public class SlotStateManager {
    private SlotState currentstate;
    private AddSlotState addSlotState;
    private RemoveSlotState removeSlotState;
    private MoveSlotState moveSlotState;

    public SlotStateManager() {
        addSlotState = new AddSlotState();
        removeSlotState = new RemoveSlotState();
        moveSlotState = new MoveSlotState();
        currentstate = moveSlotState;
    }
    public void changestate(SlotState slotState)
    {
        currentstate = slotState;
    }

    public void setAddSlotState()
    {
        if(!currentstate.equals(addSlotState))
        currentstate = addSlotState;
        else currentstate = moveSlotState;
    }

    public void setRemoveSlotState()
    {
        if(!currentstate.equals(removeSlotState))
        currentstate = removeSlotState;
        else currentstate = moveSlotState;
    }
    public void setMoveSlotState()
    {
        currentstate = moveSlotState;
    }

    public SlotState getCurrentstate() {
        return currentstate;
    }
}
