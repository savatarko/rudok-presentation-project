package view.slotstate;

import model.Slot;
import view.SlideView;
import view.slot.SlotView;

import java.awt.event.MouseEvent;

public class MoveSlotState implements SlotState{
    @Override
    public void action(MouseEvent mouseEvent, SlideView slideView) {
        //System.out.println(mouseEvent.getComponent());
        if (mouseEvent.getClickCount() == 2) {
            int x = mouseEvent.getX();
            int y = mouseEvent.getY();
            for (Slot i : slideView.getSlide().getSlotList()) {
                //var j = i.getSlot();
                double xx = slideView.getWidth() * i.getX();
                double yy = slideView.getHeight() * i.getY();
                //TODO: popravi ovo
                if (xx < x && xx + i.getWidth() * slideView.getWidth() > x && yy < y && yy + i.getHeight() * slideView.getHeight() > y) {
                    i.getSlotHandler().readContent();
                    return;
                }
            }
        }
        else {
            int x = mouseEvent.getX();
            int y = mouseEvent.getY();
            for (Slot i : slideView.getSlide().getSlotList()) {
                //var j = i.getSlot();
                double xx = slideView.getWidth() * i.getX();
                double yy = slideView.getHeight() * i.getY();
                //TODO: popravi ovo
                if (xx < x && xx + i.getWidth() * slideView.getWidth() > x && yy < y && yy + i.getHeight() * slideView.getHeight() > y) {
                /*
                slideView.getSlots().remove(i);
                slideView.getSlide().getSlotList().remove(j);
                slideView.validate();
                slideView.repaint();
                System.out.println(slideView.getSlots().size());
                slideView.getSlide().notifySubscribers(slideView.getSlide());
                return;

                 */
                    double newx = (double) mouseEvent.getX() / slideView.getWidth() - i.getWidth() / 2;
                    double newy = (double) mouseEvent.getY() / slideView.getHeight() - i.getHeight() / 2;
                    if (newx < 0)
                        newx = 0;
                    if (newy < 0)
                        newy = 0;
                    if (newx >= 1 - i.getWidth())
                        newx = 1 - i.getWidth();
                    if (newy >= 1 - i.getHeight())
                        newy = 1 - i.getHeight();
                /*
                System.out.println(newx);
                System.out.println(newy);
                System.out.println(slideView.getWidth());
                System.out.println(slideView.getHeight());

                 */
                    i.setX(newx);
                    i.setY(newy);
                    slideView.getSlide().getSlotList().remove(i);
                    slideView.getSlide().addSlot(i);
                    return;
                }
            }
        }
    }
}
