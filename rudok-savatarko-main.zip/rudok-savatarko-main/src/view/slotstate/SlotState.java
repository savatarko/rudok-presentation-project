package view.slotstate;

import view.SlideView;

import java.awt.event.MouseEvent;

public interface SlotState {
    void action(MouseEvent mouseEvent, SlideView slideView);
}
