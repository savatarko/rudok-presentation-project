package view.slotstate;

import model.Slot;
import view.SlideView;
import view.slot.SlotView;

import java.awt.event.MouseEvent;

public class RemoveSlotState implements SlotState{

    @Override
    public void action(MouseEvent mouseEvent, SlideView slideView) {
        if (mouseEvent.getClickCount() == 1) {
            int x = mouseEvent.getX();
            int y = mouseEvent.getY();
            for (Slot i : slideView.getSlide().getSlotList()) {
                //var j = i.getSlot();
                double xx = slideView.getWidth() * i.getX();
                double yy = slideView.getHeight() * i.getY();
                //TODO: popravi ovo
                if (xx < x && xx + i.getWidth() * slideView.getWidth() > x && yy < y && yy + i.getHeight() * slideView.getHeight() > y) {

                    slideView.getSlide().removeSlot(i);
                    return;
                }
            }
        }
    }
}
