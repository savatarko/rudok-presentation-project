package view.slotstate;

import model.Slot;
import view.PresentationView;
import view.SlideView;
import view.slot.SlotView;

import java.awt.event.MouseEvent;

public class AddSlotState implements SlotState{
    @Override
    public void action(MouseEvent mouseEvent, SlideView slideView) {
        if(mouseEvent.getClickCount() == 1) {
            Slot slot = new Slot(PresentationView.getSlot());
            slot.setX((float) mouseEvent.getX() / slideView.getWidth());
            slot.setY((float) mouseEvent.getY() / slideView.getHeight());
            SlotView slotView = new SlotView(slot);

            slideView.getSlide().addSlot(slot);
        }
    }
}
