package view;

import controller.listeners.SlideMouseListener;
import model.Presentation;
import model.Slide;
import observer.Subscriber;
import view.slot.SlotView;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;

public class SlideView extends JPanel implements Subscriber {
    private Presentation presentation;
    private Slide slide;
    private String backgroundPath;
    private Image background;
    private Label tmplabel;
    private boolean ispresenting = false;
    //private List<SlotView>slots = new ArrayList<>();

    SlideMouseListener slideMouseListener = new SlideMouseListener();

    public SlideView(Presentation presentation) {
        this.presentation = presentation;
        backgroundPath = presentation.getBackgroundImagePath();
        //initiialize();
    }

    public SlideView(Slide slide, int w, int h, boolean presenting) {
        this.slide = slide;
        ispresenting = presenting;
        initiialize(w,h);
    }

    private void initiialize(int w,int h)
    {

        this.setBackground(Color.white);
        backgroundPath = "test.jpg";
        background = Toolkit.getDefaultToolkit().createImage(backgroundPath);
        //this.setBackground(background);
        this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        this.setVisible(true);
        setPreferredSize(new Dimension(500,400));
        setMinimumSize(new Dimension(300,200));
        setMaximumSize(new Dimension(800, 600));
        tmplabel = new Label(slide.getName());
        this.add(tmplabel);

        ImageIcon imageIcon = new ImageIcon(((Presentation)(slide.getParent())).getBackgroundImagePath());
        Image newimage = imageIcon.getImage().getScaledInstance(w,h,Image.SCALE_FAST);
        background = newimage;
        Dimension size = new Dimension(background.getWidth(null), background.getHeight(null));

        setLayout(null);
        this.validate();
        this.repaint();
    }

    public void addmouselistener()
    {
        slideMouseListener.addSubscriber(this);
        addMouseListener(slideMouseListener);
        addMouseMotionListener(slideMouseListener);
    }

    @Override
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        g.drawImage(background,0,0,null);

        Graphics2D g2 = (Graphics2D) g;
        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.8f));
        for(int i  = slide.getSlotList().size() - 1; i>=0;i--)
        {
            if(!ispresenting) {
                SlotView s = new SlotView(slide.getSlotList().get(i));
                s.paint(g2, this.getWidth(), this.getHeight());
            }
            else
            {
                slide.getSlotList().get(i).getSlotHandler().paint(g2, this.getWidth(), this.getHeight());
            }
        }
    }

    @Override
    public void update(Object notification) {
        //this.getGraphics().clearRect(0,0,800,600);
        if(notification instanceof MouseEvent)
            //PresentationView.getSlotStateManager().getCurrentstate().action((MouseEvent) notification, this);
            ((PresentationView)MainFrame.getInstance().getProjectView().getjTabbedPane().getSelectedComponent()).getSlotStateManager().getCurrentstate().action((MouseEvent) notification, this);
        //paintComponent(this.getGraphics());
        this.repaint();
    }

    /*
    public List<SlotView> getSlots() {
        return slots;
    }

     */

    public Slide getSlide() {
        return slide;
    }
}
