package view.presentationstate;

import view.MainFrame;
import view.PresentationView;
import view.slotstate.AddSlotState;
import view.slotstate.RemoveSlotState;
import view.slotstate.SlotState;

import javax.swing.*;

public class EditToolbar extends JToolBar {
    public EditToolbar() {
        setOrientation(0);
        JToggleButton addslots = new JToggleButton(MainFrame.getInstance().getActionManager().getAddSlotAction());
        JToggleButton removeslots = new JToggleButton(MainFrame.getInstance().getActionManager().getRemoveSlotAction());
        /*
        if (slotState instanceof AddSlotState)
        {
            addslots.setSelected(true);
            removeslots.setSelected(false);
        }
        else if(slotState instanceof RemoveSlotState) {
            addslots.setSelected(false);
            removeslots.setSelected(true);
        }
        else
        {
            addslots.setSelected(false);
            removeslots.setSelected(false);
        }

         */



        //add(addslots);
        //add(removeslots);


        add(MainFrame.getInstance().getActionManager().getAddSlotAction());
        add(MainFrame.getInstance().getActionManager().getRemoveSlotAction());
        add(MainFrame.getInstance().getActionManager().getTextSlotAction());
        add(MainFrame.getInstance().getActionManager().getImageSlotAction());
        add(Box.createHorizontalGlue());
        add(MainFrame.getInstance().getActionManager().getChangeColorAction());
        add(MainFrame.getInstance().getActionManager().getChangeThicknessAction());
        add(MainFrame.getInstance().getActionManager().getChangeDottedAction());
        setRollover(false);
        setFloatable(false);
    }
}
