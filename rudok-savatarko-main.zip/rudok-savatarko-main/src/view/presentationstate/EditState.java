package view.presentationstate;

import controller.listeners.MyMouseListener;
import model.Presentation;
import model.Slide;
import view.SlideView;
import view.slotstate.SlotState;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class EditState implements State{

    private List<Slide> slides;
    private Presentation presentation;
    private Label namelabel;
    private Label authorlabel;
    private JPanel panel;
    private JScrollPane jScrollPane = new JScrollPane();
    JScrollBar jScrollBar;
    int scroll = 0;
    private JScrollPane jsidePane = new JScrollPane();
    private JPanel sidepanel;

    private EditToolbar editToolbar;

    MyMouseListener myMouseListener = new MyMouseListener();


    public JPanel draw(Presentation presentation) {
        JPanel jPanel = new JPanel();
        jPanel.setLayout(new BorderLayout());
        editToolbar = new EditToolbar();

        //this.removeAll();
        namelabel = new Label(presentation.getName());
        authorlabel = new Label(presentation.getAuthor());
        panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(Color.DARK_GRAY);

        sidepanel = new JPanel();
        sidepanel.setLayout(new BoxLayout(sidepanel, BoxLayout.Y_AXIS));
        //sidepanel.setBackground(Color.WHITE);

        jScrollPane = new JScrollPane(panel, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        jScrollPane.getVerticalScrollBar().setUnitIncrement(50);

        jsidePane = new JScrollPane(sidepanel, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        jsidePane.getVerticalScrollBar().setUnitIncrement(50);
        jScrollPane.getVerticalScrollBar().setUnitIncrement(25);
        //this.setLayout(new BorderLayout());
        if(presentation.getChildren()!=null)
            for(var i : presentation.getChildren())
            {
                if(i instanceof Slide)
                {
                    addSlide((Slide)i);
                }
            }
        jScrollPane.setMinimumSize(new Dimension(200,200));
        jScrollPane.setPreferredSize(new Dimension(650,500));
        jScrollPane.setMaximumSize(new Dimension(700,600));

        jsidePane.setMinimumSize(new Dimension(100,100));
        jsidePane.setPreferredSize(new Dimension(200,200));
        jsidePane.setMaximumSize(new Dimension(300,300));

        jScrollPane.getVerticalScrollBar().setValue(scroll);
        authorlabel.setText(presentation.getAuthor());

        /*
        this.add(authorlabel, BorderLayout.NORTH);
        this.add(jScrollPane, BorderLayout.CENTER);

         */
        JPanel jpanel1 = new JPanel();
        jpanel1.setLayout(new BorderLayout());
        jpanel1.add(editToolbar, BorderLayout.NORTH);
        jpanel1.add(jScrollPane, BorderLayout.CENTER);


        jPanel.add(authorlabel, BorderLayout.NORTH);
        jPanel.add(jpanel1, BorderLayout.CENTER);
        jPanel.add(jsidePane, BorderLayout.WEST);
        jPanel.addMouseListener(myMouseListener);
        return jPanel;
    }

    public void addSlide(Slide slide)
    {

        SlideView slideView = new SlideView(slide, 800, 600, false);
        slideView.addmouselistener();
        panel.add(Box.createVerticalStrut(15));
        panel.add(slideView);
        panel.add(Box.createVerticalStrut(15));
        slide.addSubscriber(slideView);
        SlideView slideView1 = new SlideView(slide, 100, 75, false);
        slideView1.setMaximumSize(new Dimension(100,75));
        slideView1.setMinimumSize(new Dimension(100,75));
        slideView1.setPreferredSize(new Dimension(100,75));
        sidepanel.add(Box.createVerticalStrut(15));
        sidepanel.add(slideView1);
        sidepanel.add(Box.createVerticalStrut(15));
        slide.addSubscriber(slideView1);

    }
}
