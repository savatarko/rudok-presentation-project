package view.presentationstate;

import model.Presentation;

import javax.swing.*;

public interface State {
    JPanel draw(Presentation presentation);
}
