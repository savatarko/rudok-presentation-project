package view.presentationstate;

import model.Presentation;
import model.Slide;
import view.MainFrame;
import view.PresentationView;
import view.SlideView;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PresentState implements State{

    private JButton leftbt;
    private JButton rightbt;
    private SlideView currentslide;
    int currentindex = 0;

    @Override
    public JPanel draw(Presentation presentation) {

        /*
        if(presentation.getChildren()!=null)
            currentslide = new SlideView((Slide)presentation.getChildren().get(currentindex));
        else return null;
        //TODO: NAPRAVI EXCEPTION OVDE (u else-u)

         */
        leftbt = new JButton("<");
        rightbt = new JButton(">");
        JPanel jPanel = new JPanel();
        jPanel.setLayout(new BorderLayout());


        JPanel card = new JPanel(new CardLayout());
        for(var i : presentation.getChildren())
        {
            if(i instanceof Slide)
            {
                card.add(new SlideView((Slide)i, PresentationView.getW(), PresentationView.getH(), true));
            }
        }

        leftbt.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /*
                currentindex--;
                currentslide = new SlideView((Slide)presentation.getChildren().get(currentindex));
                if(currentindex == 0)
                    leftbt.setEnabled(false);
                rightbt.setEnabled(true);

                 */
                CardLayout cardLayout = (CardLayout) card.getLayout();
                cardLayout.previous(card);
                card.validate();
                card.repaint();
                MainFrame.getInstance().getProjectView().validate();
                MainFrame.getInstance().getProjectView().repaint();
            }
        });

        rightbt.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /*
                currentindex++;
                currentslide = new SlideView((Slide)presentation.getChildren().get(currentindex));
                if(currentindex == presentation.getChildren().size() - 1)
                    rightbt.setEnabled(false);
                leftbt.setEnabled(true);
                System.out.println(currentindex);

                 */
                CardLayout cardLayout = (CardLayout) card.getLayout();
                cardLayout.next(card);
                card.validate();
                card.repaint();
                MainFrame.getInstance().getProjectView().validate();
                MainFrame.getInstance().getProjectView().repaint();
            }
        });
        //System.out.println(presentation.getChildren().size());
        jPanel.add(leftbt, BorderLayout.WEST);
        jPanel.add(rightbt,BorderLayout.EAST);
        jPanel.add(card, BorderLayout.CENTER);
        //jPanel.repaint();
        //jPanel.revalidate();
        MainFrame.getInstance().getProjectView().validate();
        MainFrame.getInstance().getProjectView().repaint();

        card.repaint();
        return jPanel;
    }
}
