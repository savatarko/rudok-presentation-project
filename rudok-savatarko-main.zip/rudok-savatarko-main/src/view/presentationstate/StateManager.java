package view.presentationstate;

import observer.Publisher;
import observer.Subscriber;

public class StateManager implements Publisher {
    private State currentState;
    private PresentState presentState;
    private EditState editState;
    private Subscriber subscriber;

    public StateManager(Subscriber sub) {
        presentState = new PresentState();
        editState = new EditState();
        currentState = editState;
        subscriber = sub;
    }

    public State getCurrentState() {
        return currentState;
    }

    public void changestate()
    {
        if(currentState.equals(presentState))
            currentState = editState;
        else currentState = presentState;
        notifySubscribers(this);
    }

    @Override
    public void notifySubscribers(Object notification) {
        subscriber.update(this);
    }

    @Override
    public void removeSubscriber(Subscriber sub) {

    }

    @Override
    public void addSubscriber(Subscriber sub) {

    }
}
