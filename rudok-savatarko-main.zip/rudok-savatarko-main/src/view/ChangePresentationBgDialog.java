package view;

import model.Presentation;
import model.RuNodeComposite;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.ActionEvent;

public class ChangePresentationBgDialog extends JDialog{
    private JTextField pathtf;
    private JButton jButton;
    JFileChooser jFileChooser;

    public ChangePresentationBgDialog(Presentation presentation) {
        initialize(presentation);
    }
    private void initialize(Presentation p) {
        /*
        pathtf = new JTextField(p.getBackgroundImagePath());
        jButton = new JButton();
        //this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        JPanel jPanel = new JPanel();
        GridLayout gridLayout = new GridLayout(2,2);
        jPanel.setLayout(gridLayout);
        jPanel.add(pathtf);
        jPanel.add(jButton);
        setLocationRelativeTo(MainFrame.getInstance());
        this.add(jPanel);
        this.setSize(new Dimension(300,200));
        jButton.setAction(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                p.setBackgroundImagePath(pathtf.getText());
                dispose();
            }
        });

         */

        jFileChooser = new JFileChooser("src/view/slideBackgrounds");
        FileNameExtensionFilter filter = new FileNameExtensionFilter("JPG & PNG Images", "jpg", "png");
        jFileChooser.setFileFilter(filter);
        int returnval = jFileChooser.showOpenDialog(MainFrame.getInstance());
        if(returnval == JFileChooser.APPROVE_OPTION)
        {
            p.setBackgroundImagePath(jFileChooser.getSelectedFile().getPath());
        }
        this.setVisible(false);
    }
}
