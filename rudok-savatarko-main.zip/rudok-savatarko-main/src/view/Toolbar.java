package view;
import javax.swing.*;

public class Toolbar extends JToolBar {
    public Toolbar() {
        setOrientation(0);
        add(MainFrame.getInstance().getActionManager().getNewProjectAction());
        add(MainFrame.getInstance().getActionManager().getSaveWorkspaceAction());
        add(MainFrame.getInstance().getActionManager().getRemoveAction());
        add(MainFrame.getInstance().getActionManager().getUndoAction());
        add(MainFrame.getInstance().getActionManager().getRedoAction());
        add(MainFrame.getInstance().getActionManager().getChangePresentationAuthorAction());
        add(MainFrame.getInstance().getActionManager().getChangePresentationBgAction());
        add(MainFrame.getInstance().getActionManager().getExitAction());
        add(Box.createHorizontalGlue());
        add(MainFrame.getInstance().getActionManager().getChangeStateAction());
        setRollover(false);
        setFloatable(false);
    }
}
