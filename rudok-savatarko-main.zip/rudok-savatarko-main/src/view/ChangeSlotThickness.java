package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class ChangeSlotThickness extends JDialog{
    public ChangeSlotThickness() {
        String v = Float.toString(PresentationView.getSlot().getStroke().getLineWidth());
        JTextArea jTextArea = new JTextArea(v);
        setLayout(new GridLayout(2,2));
        this.add(jTextArea);
        this.setLocationRelativeTo(MainFrame.getInstance());
        this.setSize(new Dimension(300,200));
        //jDialog.show();
        JButton jButton = new JButton("confirm");
        jButton.setAction(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Float value = Float.parseFloat(jTextArea.getText());
                PresentationView.getSlot().setStroke(new BasicStroke(value, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER));
                dispose();
            }
        });
        //jButton.setSize(new Dimension(200,200));
        add(jButton);

    }
}
