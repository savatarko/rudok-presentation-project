package view;

import javax.swing.*;
import java.awt.*;

public class HelpFrame extends JFrame {
    private static HelpFrame instance = null;

    public static HelpFrame getInstance() {
        if(instance == null)
            instance = new HelpFrame();
        return instance;

    }

    private HelpFrame(){
        initialize();
    }

    private void initialize()
    {
        Toolkit kit = Toolkit.getDefaultToolkit();
        Dimension screenSize = kit.getScreenSize();
        int screenHeight = screenSize.height;
        int screenWidth = screenSize.width;
        setLayout(new BorderLayout());
        setSize(screenWidth  / 5, screenHeight  / 5);
        setTitle("Info");
        setLocation(screenWidth/3, screenHeight/3);  //?napraviti da bude relativno ekranu vise?

        ImageIcon imageIcon = new ImageIcon("src/view/pic.jpg");
        JLabel jLabel = new JLabel(imageIcon);

        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);
        add(textArea, BorderLayout.CENTER);
        add(jLabel, BorderLayout.EAST);
        textArea.setText("Ivkovic Sava RN 12/20");
    }

}
