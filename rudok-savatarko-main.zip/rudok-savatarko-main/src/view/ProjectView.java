package view;

import model.Presentation;
import model.Project;
import observer.Subscriber;

import javax.swing.*;
import java.awt.*;

public class ProjectView extends JPanel implements Subscriber {
    private Project project;
    private JLabel namelabel;
    private JTabbedPane jTabbedPane;
    int index;

    public ProjectView() {
        initialize();
    }

    public Project getProject() {
        return project;
    }



    private void initialize()
    {
        namelabel = new JLabel();
        jTabbedPane = new JTabbedPane();
        jTabbedPane.setMinimumSize(new Dimension(300,200));
        this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        this.add(namelabel);
        this.add(jTabbedPane);
        this.setVisible(true);
    }


    public void setProject(Project project) {
        if(project.getChildren()!=null) {
            if (!project.equals(this.project)) {
                project.addSubscriber(this);
                namelabel.setText(project.getName());
                if (project.equals(this.project)) {
                    index = jTabbedPane.getSelectedIndex();
                } else index = 0;
                this.project = project;
                //index = jTabbedPane.getSelectedIndex();
                jTabbedPane.removeAll();
                for (var i : project.getChildren()) {
                    if (i instanceof Presentation) {
                        PresentationView presentationView = new PresentationView((Presentation) i);
                        i.addSubscriber(presentationView);
                        jTabbedPane.addTab(i.getName(), null, presentationView, null);
                    }
                }
                if(jTabbedPane.getTabCount() > 0 && index < jTabbedPane.getTabCount())
                    jTabbedPane.setSelectedIndex(index);
            }
            else
            {
                for(int i = 0 ;i<jTabbedPane.getTabCount();i++)
                {
                    PresentationView pv = (PresentationView)jTabbedPane.getComponentAt(i);
                    if(!project.getChildren().contains(pv.getPresentation()))
                    {
                        jTabbedPane.remove(i);
                        MainFrame.getInstance().refresh();
                        return;
                    }
                }
                for(var i : project.getChildren())
                {
                    boolean passed = false;
                    for(int j = 0 ;j<jTabbedPane.getTabCount(); j++)
                    {
                        PresentationView pv = (PresentationView)jTabbedPane.getComponentAt(j);
                        if(i.equals(pv.getPresentation()))
                            passed = true;
                    }
                    if(!passed)
                    {
                        PresentationView presentationView = new PresentationView((Presentation)i);
                        i.addSubscriber(presentationView);
                        jTabbedPane.addTab(i.getName(), null, presentationView, null);
                        MainFrame.getInstance().refresh();
                    }
                }
            }
        }
    }
    public void setProject(Project project, Presentation presentation)
    {
        if(!project.equals(this.project))
        {
            setProject(project);
        }
        else
        {
            int index = -1;
            for(int i = 0 ; i<jTabbedPane.getTabCount(); i++)
            {
                if(presentation.equals(((PresentationView)jTabbedPane.getComponentAt(i)).getPresentation()))
                {
                    jTabbedPane.setSelectedIndex(i);
                    return;
                }
            }
        }
    }

    public ProjectView(Project project, JLabel namelabe) {
        this.project = project;
        this.namelabel = namelabe;
    }

    @Override
    public void update(Object notification) {
        //setProject((Project)notification);
        //project = (Project) notification;
        if(!(notification instanceof Project))
        {
            setProject(this.project);
            return;
        }
        index = jTabbedPane.getSelectedIndex();
        setProject((Project) notification);
        revalidate();
        repaint();
        if(jTabbedPane.getTabCount()<index)
            jTabbedPane.setSelectedIndex(index);
    }

    public void removed()
    {
        this.jTabbedPane.removeAll();
        this.namelabel.setText("");
    }

    public JTabbedPane getjTabbedPane() {
        return jTabbedPane;
    }

}
