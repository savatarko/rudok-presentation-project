package view.slot;

import model.Slot;
import view.MainFrame;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;

public class MMSlotHandler extends SlotHandler{
    private String tempimage;

    public MMSlotHandler(Slot slot) {
        super(slot);
        content = "src/view/slot/slotimages/default.PNG";
    }

    @Override
    public void readContent()
    {
        tempimage = content.toString();
        JImageChooser jImageChooser = new JImageChooser(this, tempimage);
        jImageChooser.show();
    }
    @Override
    public void setContent(String newcontent)
    {
        content = newcontent.toString();
    }
    @Override
    public void paint(Graphics2D g2, int w, int h)
    {
        ImageIcon imageIcon = new ImageIcon(content);
        Image image = imageIcon.getImage().getScaledInstance(400,400, Image.SCALE_FAST);
        imageIcon.setImage(image);
        //g2.drawImage(image, 400, 300 , 300,200,null);
        int x = (int)(( slot.getX() * w));
        int y = (int)(( slot.getY() * h));
        int width = (int)(( slot.getWidth() * w));
        int height = (int)(( slot.getHeight() * h));

        g2.drawImage(image, x, y , width,height,null);
    }
    @Override
    public void format()
    {

    }
}
