package view.slot;

public class SlotContent {
    private String content;
}
