package view.slot;

import view.MainFrame;

import javax.swing.*;

public class JTextToolbar extends JToolBar {
    public JTextToolbar() {

        setOrientation(0);
        add(MainFrame.getInstance().getActionManager().getBoldAction());
        add(MainFrame.getInstance().getActionManager().getItalicAction());
        add(MainFrame.getInstance().getActionManager().getUnderlineAction());

        add(Box.createHorizontalGlue());

        //add(savebutton);

        setRollover(false);
        setFloatable(false);
    }
}
