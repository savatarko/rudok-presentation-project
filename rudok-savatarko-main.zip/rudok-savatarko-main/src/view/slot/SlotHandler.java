package view.slot;

import model.Slot;

import java.awt.*;
import java.io.Serializable;

public class SlotHandler implements Serializable {
    protected String content = "";
    protected Slot slot;

    public SlotHandler(Slot slot) {
        this.slot = slot;
    }

    public void readContent()
    {

    }
    public void setContent(String newcontent)
    {

    }
    public void paint(Graphics2D g2, int w, int h)
    {

    }
    public void format()
    {

    }
}
