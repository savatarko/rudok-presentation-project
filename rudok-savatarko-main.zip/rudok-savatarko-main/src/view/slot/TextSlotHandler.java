package view.slot;

import model.Slot;

import java.awt.*;
import java.awt.font.TextAttribute;
import java.util.HashMap;
import java.util.Map;

public class TextSlotHandler extends SlotHandler{

    private Map<Integer, String> fontmap = new HashMap<>();

    public TextSlotHandler(Slot slot) {
        super(slot);
    }

    public void readContent()
    {
        JTextEditor jTextEditor = new JTextEditor(this, content);
        jTextEditor.show();
    }
    public void setContent(String newcontent)
    {
        content = newcontent.toString();
    }
    public void paint(Graphics2D g2, int w, int h)
    {
        String curr = "";
        Font font = new Font(Font.SERIF, Font.PLAIN, 30);
        //g2.setFont(font);
        Map attributes = font.getAttributes();
        attributes.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_ON);
        float xcur = (float)slot.getX()*w, ycur = (float)slot.getY()*h;
        float xstart = xcur;
        g2.setFont(font);
        for(int i = 0; i<content.length() ; i++)
        {
            if(fontmap.containsKey(i))
            {
                if(curr.equals(fontmap.get(i)))
                {
                    font = new Font(Font.SERIF, Font.PLAIN, 30);
                    g2.setFont(font);
                    curr="";
                }
                else
                {
                    curr = fontmap.get(i);
                    if(curr.equals("u"))
                    {
                        g2.setFont(font.deriveFont(attributes));
                    }
                    else if(curr.equals("i"))
                    {
                        font = new Font(Font.SERIF, Font.ITALIC, 30);
                        g2.setFont(font);
                    }
                    else if(curr.equals("b"))
                    {
                        font = new Font(Font.SERIF, Font.BOLD, 30);
                        g2.setFont(font);
                    }
                }
            }
            g2.drawString(content.substring(i, i+1), xcur,ycur);
            xcur +=g2.getFontMetrics().stringWidth(content.substring(i, i+1));
            if(xcur > (slot.getX() + slot.getWidth())*w)
            {
                xcur = xstart;
                ycur += g2.getFontMetrics().getHeight();
            }
        }

    }
    public void format()
    {

    }

    public Map<Integer, String> getFontmap() {
        return fontmap;
    }

    public void setFontmap(Map<Integer, String> fontmap) {
        this.fontmap = fontmap;
    }
}
