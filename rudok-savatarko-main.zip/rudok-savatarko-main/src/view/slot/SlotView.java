package view.slot;

import lombok.Getter;
import lombok.Setter;
import model.Slot;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.GeneralPath;

@Getter
@Setter

public class SlotView {
    private Slot slot;
    private Shape shape;
    private Rectangle rectangle = new Rectangle();
    //private SlotHandler slotHandler;

    public SlotView(Slot slot) {
        this.slot = slot;
    }

    public void paint(Graphics2D g, int x,int y)
    {
        g.setPaint(slot.getColor());
        if(slot.getStroke() == null)
        {
            slot.setStroke(new BasicStroke());
        }
        g.setStroke(slot.getStroke());
        //g.draw(rectangle);
        g.setPaint(Color.BLACK);
        shape = new GeneralPath();
        ((GeneralPath)shape).moveTo(slot.getX()*x,slot.getY()*y);

        ((GeneralPath)shape).lineTo(slot.getX() * x+slot.getWidth() * x,slot.getY() * y);

        ((GeneralPath)shape).lineTo(slot.getX() * x+slot.getWidth() * x,slot.getY() * y+slot.getHeight() * y);

        ((GeneralPath)shape).lineTo(slot.getX() * x,slot.getY()*y+slot.getHeight() * y);

        ((GeneralPath)shape).closePath();
        g.draw(shape);
        g.setPaint(slot.getColor());
        g.fill(shape);
    }
}
