package view.slot;

import view.MainFrame;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.ActionEvent;

public class JImageChooser extends JDialog {
    private JPanel jPanel;
    private JButton savebutton;
    private JButton openbutton;
    private String temp;
    private ImageIcon imageIcon;
    private Image image;
    private JLabel jLabel;
    private JPanel jPanel1;

    public JImageChooser(MMSlotHandler mmSlotHandler, String src) {
        initialize(mmSlotHandler, src);
    }
    private void initialize(MMSlotHandler mmSlotHandler, String src)
    {
        if(temp==null)
            temp = src;
        jPanel = new JPanel();
        savebutton = new JButton("Save");
        openbutton = new JButton("Open");
        openbutton.setAction(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {

                JFileChooser jFileChooser = new JFileChooser("src/view/slot/slotimages");
                FileNameExtensionFilter filter = new FileNameExtensionFilter("JPG & PNG Images", "jpg", "png");
                jFileChooser.setFileFilter(filter);
                //jDialog.add(jFileChooser);
                //jDialog.show();
                int returnval = jFileChooser.showOpenDialog(MainFrame.getInstance());
                if(returnval == JFileChooser.APPROVE_OPTION)
                {
                    setnewimage(jFileChooser.getSelectedFile().getPath());

                    JImageChooser.this.validate();
                    JImageChooser.this.repaint();
                }
            }
        });
        savebutton.setAction(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mmSlotHandler.setContent(temp);
                JImageChooser.this.dispose();
            }
        });
        savebutton.setText("Save");
        openbutton.setText("Open");
        setLayout(new BorderLayout());
        imageIcon = new ImageIcon(temp);
        image = imageIcon.getImage().getScaledInstance(400,400, Image.SCALE_FAST);
        imageIcon.setImage(image);

        jLabel = new JLabel(imageIcon);
        //add(savebutton);
        //add(openbutton);
        setPreferredSize(new Dimension(600,600));
        setLocationRelativeTo(MainFrame.getInstance());
        setSize(new Dimension(600,600));

        add(jLabel, BorderLayout.CENTER);
        jPanel1 = new JPanel();
        BoxLayout boxLayout = new BoxLayout(jPanel1, BoxLayout.Y_AXIS);
        jPanel1.add(openbutton);
        jPanel1.add(savebutton);
        this.add(jPanel1, BorderLayout.EAST);
        //this.requestFocusInWindow();
    }
    public void setnewimage(String s)
    {
        temp = s;
        imageIcon = new ImageIcon(temp);
        image = imageIcon.getImage().getScaledInstance(400,400, Image.SCALE_FAST);
        imageIcon.setImage(image);
        jLabel.setIcon(imageIcon);
        jLabel.validate();
        jLabel.repaint();
        this.repaint();
    }
}
