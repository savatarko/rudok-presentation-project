package view.slot;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.jbosslog.JBossLog;
import view.MainFrame;

import javax.swing.*;
import javax.swing.text.AttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyledDocument;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.font.TextAttribute;
import java.util.HashMap;
import java.util.Map;

public class JTextEditor extends JDialog{
    private JTextPane jTextPane;
    private JTextToolbar jTextToolbar;
    private JButton savebutton;
    private static String fontmode;
    private Map<Integer, String> fontmap = new HashMap<>();
    private Map<String, Font> fonts = new HashMap<>();
    private String curr = "";
    private Font font;

    public JTextEditor(TextSlotHandler textSlotHandler, String content) {
        initialize(textSlotHandler, content);
    }
    private void initialize(TextSlotHandler textSlotHandler, String content)
    {
        jTextPane = new JTextPane();
        jTextToolbar = new JTextToolbar();
        savebutton = new JButton();
        jTextToolbar.add(savebutton);
        this.setLayout(new BorderLayout());
        this.add(jTextToolbar, BorderLayout.NORTH);
        this.add(jTextPane, BorderLayout.CENTER);
        this.setLocationRelativeTo(MainFrame.getInstance());
        this.setSize(new Dimension(600,400));
        this.setTitle("Text editor");
        font = new Font(Font.SERIF, Font.PLAIN, 20);
        Map attributes = font.getAttributes();
        attributes.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_ON);
        //jTextPane.setText(content);
        for(int i = 0; i<content.length(); i++)
        {
            if(fontmap.containsKey(i)) {
                if (curr.equals(fontmap.get(i))) {
                    font = new Font(Font.SERIF, Font.PLAIN, 20);
                    jTextPane.setFont(font);
                    curr = "";
                } else {
                    curr = fontmap.get(i);
                    if (curr.equals("u")) {
                        jTextPane.setFont(font.deriveFont(attributes));
                    } else if (curr.equals("i")) {
                        font = new Font(Font.SERIF, Font.ITALIC, 20);
                        jTextPane.setFont(font);
                    } else if (curr.equals("b")) {
                        font = new Font(Font.SERIF, Font.BOLD, 20);
                        jTextPane.setFont(font);
                    }
                }
            }
            try{
                jTextPane.getStyledDocument().insertString(0, content.substring(i,i+1), jTextPane.getParagraphAttributes());
            }
            catch (Exception exception)
            {
                exception.printStackTrace();
            }
        }
        /*
        try {
            doc.insertString(0, "test1", jTextPane.getParagraphAttributes());

        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }

         */
        //Map attributes = font.getAttributes();
        attributes.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_ON);

        fonts.put("u", font.deriveFont(attributes));
        fonts.put("i", new Font(Font.SERIF, Font.ITALIC, 25));
        fonts.put("b", new Font(Font.SERIF, Font.BOLD, 25));
        fonts.put("", new Font(Font.SERIF, Font.PLAIN, 25));
        //jTextPane.setFont(new Font(Font.SERIF, Font.BOLD, 30));

        savebutton.setAction(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textSlotHandler.setContent(jTextPane.getText());
                textSlotHandler.setFontmap(fontmap);
                JTextEditor.this.dispose();
            }
        });
        savebutton.setText("Save");
    }

    public void updateFont(String font)
    {
        int index = jTextPane.getText().length();
        if(fontmap.containsKey(index))
        {
            if(fontmap.get(index).equals(font))
            {
                fontmap.put(index, "");
                jTextPane.setFont(new Font(Font.SERIF, Font.PLAIN, 20));
            }
            else {
                fontmap.put(index, font);
            }
        }
        else fontmap.put(index, font);
        if(curr.equals(font))
        {
            curr = "";
            jTextPane.setFont(new Font(Font.SERIF, Font.PLAIN, 20));
        }
        else
        {
            curr = font;
        }
        if(curr.equals("b"))
        {
            jTextPane.setFont(new Font(Font.SERIF, Font.BOLD, 20));
        }
        else if(curr.equals("i"))
        {
            jTextPane.setFont(new Font(Font.SERIF, Font.ITALIC, 20));
        }
        else if(curr.equals("u"))
        {
            Map attributes = this.font.getAttributes();
            attributes.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_ON);
            jTextPane.setFont(this.font.deriveFont(attributes));
        }
    }

    public static String getFontmode() {
        return fontmode;
    }

    public static void setFontmode(String fontmode) {
        JTextEditor.fontmode = fontmode;
    }

    public Map<Integer, String> getFontmap() {
        return fontmap;
    }

    public void setFontmap(Map<Integer, String> fontmap) {
        this.fontmap = fontmap;
    }
}
