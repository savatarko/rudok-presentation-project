package view;

import javax.swing.*;

public class Menubar extends JMenuBar {

    public Menubar() {
        JMenu file = new JMenu("File");
        JMenu edit = new JMenu("Edit");
        JMenu help = new JMenu("Help");
        JMenu remove = new JMenu("Remove");
        file.add(MainFrame.getInstance().getActionManager().getNewProjectAction());
        file.add(MainFrame.getInstance().getActionManager().getSaveWorkspaceAction());
        file.add(MainFrame.getInstance().getActionManager().getOpenWorkspace());
        file.add(MainFrame.getInstance().getActionManager().getSaveProjectAction());
        file.add(MainFrame.getInstance().getActionManager().getOpenProjectAction());
        file.add(MainFrame.getInstance().getActionManager().getSavepresentationAction());
        file.add(MainFrame.getInstance().getActionManager().getOpenPresentationAction());
        file.add(MainFrame.getInstance().getActionManager().getRemoveAction());

        edit.add(MainFrame.getInstance().getActionManager().getUndoAction());
        edit.add(MainFrame.getInstance().getActionManager().getRedoAction());
        edit.add(MainFrame.getInstance().getActionManager().getChangePresentationAuthorAction());
        edit.add(MainFrame.getInstance().getActionManager().getChangePresentationBgAction());
        help.add(MainFrame.getInstance().getActionManager().getHelpAction());
        add(file);
        add(edit);
        add(help);
    }
}
