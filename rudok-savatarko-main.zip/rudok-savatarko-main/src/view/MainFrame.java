package view;

import controller.actions.ActionManager;
import errorfactory.Error;
import errorfactory.ErrorFactory;
import lombok.Getter;
import lombok.Setter;
import model.jtree.MyTree;
import model.jtree.MyTreeModel;
import model.jtree.MyTreeNode;
import observer.Subscriber;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

@Getter
@Setter

public class MainFrame extends JFrame implements Subscriber {

    private static MainFrame instance = null;
    Menubar menu;
    JToolBar toolBar;
    private Object NewProjectAction;
   // FlowLayout left;
    JSplitPane splitPane;
    JScrollPane scrollPane;
    JPanel panel;
    MyTree myTree;
    MyTreeModel myTreeModel;
    ProjectView projectView;

    public static String wspath = "src/workspace/workspace.txt";

    private ErrorFactory errorFactory;

    JTabbedPane jTabbedPane;

    private ActionManager actionManager;

    private MyTreeNode clipboardnode;

    private StartDialog startDialog;

    private MainFrame()
    {
        actionManager = new ActionManager();
    }

    private void initialize()
    {
        Toolkit kit = Toolkit.getDefaultToolkit();
        Dimension screenSize = kit.getScreenSize();
        int screenHeight = screenSize.height;
        int screenWidth = screenSize.width;
        setSize(screenWidth * 3 / 4, screenHeight * 3 / 4);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                super.windowClosing(e);
                MainFrame.getInstance().getActionManager().getSaveWorkspaceAction().actionPerformed(null);
            }
        });
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(WindowEvent e) {
                super.windowOpened(e);
                startDialog = new StartDialog();
                startDialog.show();
                startDialog.toFront();
            }
        });
        setTitle("PowerPoint");

        toolBar = new Toolbar();
        menu = new Menubar();
        setJMenuBar(menu);
        add(toolBar, BorderLayout.NORTH);

        projectView = new ProjectView();

        initializeMyTree();

        jTabbedPane = new JTabbedPane();

        scrollPane = new JScrollPane(myTree);
        panel = new JPanel();
        scrollPane.setMinimumSize(new Dimension(300,300));

        splitPane=new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, scrollPane, projectView);
        splitPane.setDividerLocation(300);
        add(splitPane,BorderLayout.CENTER);
        ImageIcon image = new ImageIcon("src/view/icon.png");
        setIconImage(image.getImage());

        errorFactory = new ErrorFactory();


    }

     public static MainFrame getInstance()
    {
        if(instance == null) {
            instance = new MainFrame();
            instance.initialize();
        }
        return instance;
    }

    private void initializeMyTree()
    {
        myTree = new MyTree();
        myTreeModel = new MyTreeModel();
        myTree.setModel(myTreeModel);
    }

    public JTabbedPane getjTabbedPane() {
        return jTabbedPane;
    }

    public MyTree getMyTree() {
        return myTree;
    }

    public ProjectView getProjectView() {
        return projectView;
    }

    @Override
    public void update(Object notification) {
        JDialog error = new JDialog();
        error.setTitle("Error");
        JTextPane jTextPane = new JTextPane();
        if(notification instanceof Error)
        {
            jTextPane.setText(((Error) notification).getMessage());
        }
        jTextPane.setEditable(false);
        error.add(jTextPane);
        error.setSize(new Dimension(300,200));
        error.setLocationRelativeTo(MainFrame.getInstance());
        error.setVisible(true);

        Thread.currentThread().stop();
    }

    public void refresh()
    {
        MainFrame.getInstance().repaint();
        try{
            Thread.sleep(30);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

}
