package errorfactory;

public class JTreeSlideSelectionError implements Error{

    @Override
    public String getMessage() {
        return "Ne moze se dodati nista na slajd";
    }
}
