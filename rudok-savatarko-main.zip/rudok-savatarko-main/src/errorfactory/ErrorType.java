package errorfactory;

public enum ErrorType {
    noselectionerror, treeslideselection, renamenullerror
}
