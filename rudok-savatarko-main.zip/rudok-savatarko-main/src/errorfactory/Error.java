package errorfactory;

public interface Error {
    String getMessage();
}
