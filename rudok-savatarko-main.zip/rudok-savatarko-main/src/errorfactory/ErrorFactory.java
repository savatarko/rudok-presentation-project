package errorfactory;

import observer.Publisher;
import observer.Subscriber;
import view.MainFrame;

public class ErrorFactory implements Publisher {

    private static ErrorFactory errorFactory;

    private Subscriber mainFrame;

    private NoSelectionError noSelectionError;
    private JTreeSlideSelectionError jTreeSlideSelectionError;
    private RenameNullError renameNullError;

    public static ErrorFactory getErrorFactory() {
        if(errorFactory ==null)
            errorFactory = new ErrorFactory();
        return errorFactory;
    }

    public ErrorFactory() {
        addSubscriber(MainFrame.getInstance());

        noSelectionError = new NoSelectionError();
        jTreeSlideSelectionError = new JTreeSlideSelectionError();
        renameNullError = new RenameNullError();
    }

    public void generateError(ErrorType errorType)
    {
        if(errorType == ErrorType.noselectionerror)
        {
            notifySubscribers(noSelectionError);
        }
        else if(errorType == ErrorType.treeslideselection)
        {
            notifySubscribers(jTreeSlideSelectionError);
        }
        else if(errorType == ErrorType.renamenullerror)
        {
            notifySubscribers(renameNullError);
        }

    }

    @Override
    public void notifySubscribers(Object notification) {
        mainFrame.update(notification);
    }

    @Override
    public void removeSubscriber(Subscriber sub) {
        mainFrame = null;
    }

    @Override
    public void addSubscriber(Subscriber sub) {
        mainFrame = sub;
    }
}
