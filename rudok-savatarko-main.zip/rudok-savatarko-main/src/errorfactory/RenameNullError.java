package errorfactory;

public class RenameNullError implements Error{
    @Override
    public String getMessage() {
        return "Name can't be empty!";
    }
}
