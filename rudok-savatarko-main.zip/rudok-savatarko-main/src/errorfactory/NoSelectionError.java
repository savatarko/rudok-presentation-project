package errorfactory;

import view.MainFrame;

import javax.swing.*;
import java.awt.*;

public class NoSelectionError implements Error{

    public String getMessage() {
        /*
        JDialog jDialog = new JDialog();
        JTextArea jTextArea = new JTextArea("Please select something in tree");
        jTextArea.setEditable(false);
        jDialog.add(jTextArea);
        jDialog.setLocationRelativeTo(MainFrame.getInstance());
        jDialog.setSize(new Dimension(300,200));
        jDialog.show();

         */
        return "Please select something in the tree";
    }
}
