package serialization;

import model.Project;

import java.io.IOException;
import java.io.Serializable;

public class SerializableProjectAdapter implements Serializable {
    Project project;

    public SerializableProjectAdapter(Project project) {
        this.project = project;
    }

    public void writeObject(java.io.ObjectOutputStream out) throws IOException
    {
        out.writeObject(project);
    }
}
