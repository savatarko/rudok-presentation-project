package observer;

public interface Publisher {
    void notifySubscribers(Object notification);
    void removeSubscriber(Subscriber sub);
    void addSubscriber(Subscriber sub);
}
