package observer;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class Notification {
    private Object object;
    private NotificationType notificationType;

    public Notification(Object object, NotificationType notificationType) {
        this.object = object;
        this.notificationType = notificationType;
    }


}
