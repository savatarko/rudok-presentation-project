package observer;

public enum NotificationType {
    DELETE, ADD
}
